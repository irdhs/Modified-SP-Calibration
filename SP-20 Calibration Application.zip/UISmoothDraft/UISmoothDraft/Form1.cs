﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UISmoothDraft
{
    public partial class Form1 : Form
    {
        #region Variabel
        Gazepoint GP = new Gazepoint();

        int[][] b;
        int[] a;
        #endregion


        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 Fullscreen = new Form2(this);
            Fullscreen.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UIValidasi Validasi = new UIValidasi();
            Validasi.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Chart Grafik = new Chart();
            //Grafik.Item(b);
            //Grafik.Item2(a);
            Grafik.Show();
        }

        public int[][] Item(int[][] x)
        {
            b = new int[x.Length][];
            for (int i = 0; i < x.Length; i++)
            {
                b[i] = new int[2];
                b[i][0] = x[i][0];
                b[i][1] = x[i][1];
                Debug.WriteLine(" b " + i + b[i][0]);
            }
            return b;
        }

        public int[] Item2(int[] x)
        {
            a = new int[x.Length];
            for(int i = 0; i< x.Length; i++)
            {
                a[i] = x[i];
            }
            return a;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Fixation fix = new Fixation();
            fix.Show();

        }
    }
}
