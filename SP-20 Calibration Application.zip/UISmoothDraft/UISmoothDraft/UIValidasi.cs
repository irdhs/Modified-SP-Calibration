﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;

namespace UISmoothDraft
{
    public partial class UIValidasi : Form
    {
        #region Setting graphic form
        static int lebar = Screen.PrimaryScreen.Bounds.Width;
        static int tinggi = Screen.PrimaryScreen.Bounds.Height;
        Bitmap bmp = new Bitmap(lebar, tinggi);
        Bitmap bmp2 = new Bitmap(lebar, tinggi);
        Graphics g;
        #endregion

        #region Setting drawing lingkaran kalibrasi
        int radius = tinggi / 2 - 50; // tentukan radius lingakaran
        int centerx = lebar / 2; // tentukan titik tengah posisi x
        int centery = tinggi / 2; // tentukan titik tengah posisi y
        int angle = 0;

        //lingkaran luar
        static int titikX1 = (int)(lebar * 0.1);
        static int titikX2 = (int)(lebar * 0.5);
        int titikX3 = (int)(lebar * 0.9);
        static int titikY1 = (int)(tinggi * 0.1);
        static int titikY2 = (int)(tinggi * 0.5);
        int titikY3 = (int)(tinggi * 0.9);

        //lingkaran dalam
        static int titikX4 = (int)(lebar * 0.4);
        static int titikX5 = (int)(lebar * 0.6);
        static int titikY4 = (int)(tinggi * 0.4);
        static int titikY5 = (int)(tinggi * 0.6);

        #endregion

        #region koordinat titik
        int timesec = 0;
        int timesec2 = 0, timesec3 = 0, timesec4 = 0, timesec5 = 0;
        int timesec6 = 0, timesec7 = 0, timesec8 = 0, timesec9 = 0;
        int timesec10 = 0, timesec11 = 0, timesec12 = 0, timesec13 = 0;
        int timesec14 = 0, timesec15 = 0, timesec16 = 0, timesec17 = 0;
        int a;
        int b;
        List<double> X1 = new List<double>();
        List<double> X2 = new List<double>();
        List<double> X3 = new List<double>();
        List<double> X4 = new List<double>();
        List<double> X5 = new List<double>();
        List<double> X6 = new List<double>();
        List<double> X7 = new List<double>();
        List<double> X8 = new List<double>();
        List<double> X9 = new List<double>();
        List<double> Y1 = new List<double>();
        List<double> Y2 = new List<double>();
        List<double> Y3 = new List<double>();
        List<double> Y4 = new List<double>();
        List<double> Y5 = new List<double>();
        List<double> Y6 = new List<double>();
        List<double> Y7 = new List<double>();
        List<double> Y8 = new List<double>();
        List<double> Y9 = new List<double>();

        List<double> X10 = new List<double>();
        List<double> X11 = new List<double>();
        List<double> X12 = new List<double>();
        List<double> X13 = new List<double>();
        List<double> X14 = new List<double>();
        List<double> X15 = new List<double>();
        List<double> X16 = new List<double>();
        List<double> X17 = new List<double>();
        List<double> Y10 = new List<double>();
        List<double> Y11 = new List<double>();
        List<double> Y12 = new List<double>();
        List<double> Y13 = new List<double>();
        List<double> Y14 = new List<double>();
        List<double> Y15 = new List<double>();
        List<double> Y16 = new List<double>();
        List<double> Y17 = new List<double>();


        static int x1;
        static int y1;
        static int x2;
        static int y2;

        double errx1, errx2, errx3, errx4, errx5, errx6, errx7, errx8, errx9;
        double errx10, errx11, errx12, errx13, errx14, errx15, errx16, errx17;
        double erry1, erry2, erry3, erry4, erry5, erry6, erry7, erry8, erry9;
        double erry10, erry11, erry12, erry13, erry14, erry15, erry16, erry17;

        #endregion

        #region Gazepoint dan BackgroundWorker
        BackgroundWorker work = new BackgroundWorker();
        Gazepoint GP = new Gazepoint();
        double[] Hasil = new double[4];
        bool record = false;
        bool status = false;
        int ixx = 0;
        #endregion

        public UIValidasi()
        {
            InitializeComponent();
        }

        private void UIValidasi_Load(object sender, EventArgs e)
        {
            int w = Screen.PrimaryScreen.Bounds.Width;
            int h = Screen.PrimaryScreen.Bounds.Height;
            this.Location = new Point(0, 0);
            this.Size = new Size(w, h);

            GP.HidupkanGazepoint();
            work.DoWork += backgroundWorker1_DoWork;
            work.RunWorkerAsync();

            g = Graphics.FromImage(bmp);
            pictureBox1.Image = bmp;
            g.Clear(Color.Black);
            //g.DrawEllipse(new Pen(Color.Black, 1f), centerx - radius, centery - radius, radius * 2, radius * 2);
            g.FillEllipse(Brushes.Red, titikX1 - 15, titikY1 - 15, 30, 30); // Titik Luar 1
            g.FillEllipse(Brushes.Red, titikX2 - 15, titikY1 - 15, 30, 30); // Titik Luar 2
            g.FillEllipse(Brushes.Red, titikX3 - 15, titikY1 - 15, 30, 30); // Titik Luar 3
            g.FillEllipse(Brushes.Red, titikX1 - 15, titikY2 - 15, 30, 30); // Titik Luar 4 
            g.FillEllipse(Brushes.Red, titikX3 - 15, titikY2 - 15, 30, 30); // Titik Luar 5
            g.FillEllipse(Brushes.Red, titikX1 - 15, titikY3 - 15, 30, 30); // Titik Luar 6
            g.FillEllipse(Brushes.Red, titikX2 - 15, titikY3 - 15, 30, 30); // Titik Luar 7
            g.FillEllipse(Brushes.Red, titikX3 - 15, titikY3 - 15, 30, 30); // Titik Luar 8

            g.FillEllipse(Brushes.Red, titikX4 - 15, titikY4 - 15, 30, 30); // Titik Dalam 1
            g.FillEllipse(Brushes.Red, titikX2 - 15, titikY4 - 15, 30, 30); // Titik Dalam 2
            g.FillEllipse(Brushes.Red, titikX5 - 15, titikY4 - 15, 30, 30); // Titik Dalam 3
            g.FillEllipse(Brushes.Red, titikX4 - 15, titikY2 - 15, 30, 30); // Titik Dalam 4
            g.FillEllipse(Brushes.Red, titikX2 - 15, titikY2 - 15, 30, 30); // Titik Dalam 5
            g.FillEllipse(Brushes.Red, titikX5 - 15, titikY2 - 15, 30, 30); // Titik Dalam 6
            g.FillEllipse(Brushes.Red, titikX4 - 15, titikY5 - 15, 30, 30); // Titik Dalam 7
            g.FillEllipse(Brushes.Red, titikX2 - 15, titikY5 - 15, 30, 30); // Titik Dalam 8
            g.FillEllipse(Brushes.Red, titikX5 - 15, titikY5 - 15, 30, 30); // Titik Dalam 9
        }

        private void UIValidasi_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                this.Close();

                #region tulis output
                using (StreamWriter outputFX = new StreamWriter("C:\\Users\\Lenovo\\Desktop\\EKSPERIMEN KALIBRASI\\FX.txt", true))
                {
                    outputFX.WriteLine("");

                    outputFX.WriteLine(" ==================== FIXATION ======================= ");
                    outputFX.WriteLine(" ===== Data Gaze ====== ");
                    outputFX.WriteLine(" Target X : " + titikX1);
                    for (int i = 0; i < X1.Count; i++)
                    {
                        outputFX.WriteLine("Gaze X : " + X1[i] * lebar);
                    }
                    outputFX.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                    outputFX.WriteLine(" Target Y: " + titikY1);
                    for (int i = 0; i < Y1.Count; i++)
                    {
                        outputFX.WriteLine("Gaze Y : " + Y1[i] * tinggi);
                    }
                    outputFX.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                    outputFX.WriteLine("error x 1 : " + errx1);
                    outputFX.WriteLine("error y 1 : " + erry1);

                    outputFX.WriteLine(" ===== Data Gaze ====== ");
                    outputFX.WriteLine(" Target X : " + titikX2);
                    for (int i = 0; i < X2.Count; i++)
                    {
                        outputFX.WriteLine("Gaze X : " + X2[i] * lebar);
                    }
                    outputFX.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                    outputFX.WriteLine(" Target Y: " + titikY1);
                    for (int i = 0; i < Y2.Count; i++)
                    {
                        outputFX.WriteLine("Gaze Y : " + Y2[i] * tinggi);
                    }
                    outputFX.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                    outputFX.WriteLine("error x 2 : " + errx2);
                    outputFX.WriteLine("error y 2 : " + erry2);

                    outputFX.WriteLine(" ===== Data Gaze ====== ");
                    outputFX.WriteLine(" Target X : " + titikX3);
                    for (int i = 0; i < X3.Count; i++)
                    {
                        outputFX.WriteLine("Gaze X : " + X3[i] * lebar);
                    }
                    outputFX.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                    outputFX.WriteLine(" Target Y: " + titikY1);
                    for (int i = 0; i < Y3.Count; i++)
                    {
                        outputFX.WriteLine("Gaze Y : " + Y3[i] * tinggi);
                    }
                    outputFX.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                    outputFX.WriteLine("error x 3 : " + errx3);
                    outputFX.WriteLine("error y 3 : " + erry3);
                    // =====================================================================
                    outputFX.WriteLine(" ===== Data Gaze ====== ");
                    outputFX.WriteLine(" Target X : " + titikX1);
                    for (int i = 0; i < X4.Count; i++)
                    {
                        outputFX.WriteLine("Gaze X : " + X4[i] * lebar);
                    }
                    outputFX.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                    outputFX.WriteLine(" Target Y: " + titikY2);
                    for (int i = 0; i < Y4.Count; i++)
                    {
                        outputFX.WriteLine("Gaze Y : " + Y4[i] * tinggi);
                    }
                    outputFX.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                    outputFX.WriteLine("error x 4 : " + errx4);
                    outputFX.WriteLine("error y 4 : " + erry4);
                    // =======================================================================
                    outputFX.WriteLine(" ===== Data Gaze ====== ");
                    outputFX.WriteLine(" Target X : " + titikX3);
                    for (int i = 0; i < X6.Count; i++)
                    {
                        outputFX.WriteLine("Gaze X : " + X6[i] * lebar);
                    }
                    outputFX.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                    outputFX.WriteLine(" Target Y: " + titikY2);
                    for (int i = 0; i < Y6.Count; i++)
                    {
                        outputFX.WriteLine("Gaze Y : " + Y6[i] * tinggi);
                    }
                    outputFX.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                    outputFX.WriteLine("error x 6 : " + errx6);
                    outputFX.WriteLine("error y 6 : " + erry6);
                    // ========================================================================
                    outputFX.WriteLine(" ===== Data Gaze ====== ");
                    outputFX.WriteLine(" Target X : " + titikX1);
                    for (int i = 0; i < X7.Count; i++)
                    {
                        outputFX.WriteLine("Gaze X : " + X7[i] * lebar);
                    }
                    outputFX.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                    outputFX.WriteLine(" Target Y: " + titikY3);
                    for (int i = 0; i < Y7.Count; i++)
                    {
                        outputFX.WriteLine("Gaze Y : " + Y7[i] * tinggi);
                    }
                    outputFX.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                    outputFX.WriteLine("error x 7 : " + errx7);
                    outputFX.WriteLine("error y 7 : " + erry7);
                    // ========================================================================
                    outputFX.WriteLine(" ===== Data Gaze ====== ");
                    outputFX.WriteLine(" Target X : " + titikX2);
                    for (int i = 0; i < X8.Count; i++)
                    {
                        outputFX.WriteLine("Gaze X : " + X8[i] * lebar);
                    }
                    outputFX.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                    outputFX.WriteLine(" Target Y: " + titikY3);
                    for (int i = 0; i < Y8.Count; i++)
                    {
                        outputFX.WriteLine("Gaze Y : " + Y8[i] * tinggi);
                    }
                    outputFX.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                    outputFX.WriteLine("error x 8 : " + errx8);
                    outputFX.WriteLine("error y 8 : " + erry8);
                    // ========================================================================
                    outputFX.WriteLine(" ===== Data Gaze ====== ");
                    outputFX.WriteLine(" Target X : " + titikX3);
                    for (int i = 0; i < X9.Count; i++)
                    {
                        outputFX.WriteLine("Gaze X : " + X9[i] * lebar);
                    }
                    outputFX.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                    outputFX.WriteLine(" Target Y: " + titikY3);
                    for (int i = 0; i < Y9.Count; i++)
                    {
                        outputFX.WriteLine("Gaze Y : " + Y9[i] * tinggi);
                    }
                    outputFX.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                    outputFX.WriteLine("error x 9 : " + errx9);
                    outputFX.WriteLine("error y 9 : " + erry9);
                    // ========================================================================
                    outputFX.WriteLine(" ===== Data Gaze ====== ");
                    outputFX.WriteLine(" Target X : " + titikX4);
                    for (int i = 0; i < X10.Count; i++)
                    {
                        outputFX.WriteLine("Gaze X : " + X10[i] * lebar);
                    }
                    outputFX.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                    outputFX.WriteLine(" Target Y: " + titikY4);
                    for (int i = 0; i < Y10.Count; i++)
                    {
                        outputFX.WriteLine("Gaze Y : " + Y10[i] * tinggi);
                    }
                    outputFX.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                    outputFX.WriteLine("error x 10 : " + errx10);
                    outputFX.WriteLine("error y 10 : " + erry10);
                    // ========================================================================
                    outputFX.WriteLine(" ===== Data Gaze ====== ");
                    outputFX.WriteLine(" Target X : " + titikX2);
                    for (int i = 0; i < X11.Count; i++)
                    {
                        outputFX.WriteLine("Gaze X : " + X11[i] * lebar);
                    }
                    outputFX.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                    outputFX.WriteLine(" Target Y: " + titikY4);
                    for (int i = 0; i < Y11.Count; i++)
                    {
                        outputFX.WriteLine("Gaze Y : " + Y11[i] * tinggi);
                    }
                    outputFX.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                    outputFX.WriteLine("error x 11 : " + errx11);
                    outputFX.WriteLine("error y 11 : " + erry11);
                    // ========================================================================
                    outputFX.WriteLine(" ===== Data Gaze ====== ");
                    outputFX.WriteLine(" Target X : " + titikX5);
                    for (int i = 0; i < X12.Count; i++)
                    {
                        outputFX.WriteLine("Gaze X : " + X12[i] * lebar);
                    }
                    outputFX.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                    outputFX.WriteLine(" Target Y: " + titikY4);
                    for (int i = 0; i < Y12.Count; i++)
                    {
                        outputFX.WriteLine("Gaze Y : " + Y12[i] * tinggi);
                    }
                    outputFX.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                    outputFX.WriteLine("error x 12 : " + errx12);
                    outputFX.WriteLine("error y 12 : " + erry12);
                    // ========================================================================
                    outputFX.WriteLine(" ===== Data Gaze ====== ");
                    outputFX.WriteLine(" Target X : " + titikX4);
                    for (int i = 0; i < X13.Count; i++)
                    {
                        outputFX.WriteLine("Gaze X : " + X13[i] * lebar);
                    }
                    outputFX.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                    outputFX.WriteLine(" Target Y: " + titikY2);
                    for (int i = 0; i < Y13.Count; i++)
                    {
                        outputFX.WriteLine("Gaze Y : " + Y13[i] * tinggi);
                    }
                    outputFX.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                    outputFX.WriteLine("error x 13 : " + errx13);
                    outputFX.WriteLine("error y 13 : " + erry13);
                    //========================================================================
                    outputFX.WriteLine(" ===== Data Gaze ====== ");
                    outputFX.WriteLine(" Target X : " + titikX2);
                    for (int i = 0; i < X5.Count; i++)
                    {
                        outputFX.WriteLine("Gaze X : " + X5[i] * lebar);
                    }
                    outputFX.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                    outputFX.WriteLine(" Target Y: " + titikY2);
                    for (int i = 0; i < Y5.Count; i++)
                    {
                        outputFX.WriteLine("Gaze Y : " + Y5[i] * tinggi);
                    }
                    outputFX.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                    outputFX.WriteLine("error x 5 : " + errx5);
                    outputFX.WriteLine("error y 5 : " + erry5);
                    // ========================================================================
                    outputFX.WriteLine(" ===== Data Gaze ====== ");
                    outputFX.WriteLine(" Target X : " + titikX5);
                    for (int i = 0; i < X14.Count; i++)
                    {
                        outputFX.WriteLine("Gaze X : " + X14[i] * lebar);
                    }
                    outputFX.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                    outputFX.WriteLine(" Target Y: " + titikY2);
                    for (int i = 0; i < Y14.Count; i++)
                    {
                        outputFX.WriteLine("Gaze Y : " + Y14[i] * tinggi);
                    }
                    outputFX.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                    outputFX.WriteLine("error x 14 : " + errx14);
                    outputFX.WriteLine("error y 14 : " + erry14);
                    // ========================================================================
                    outputFX.WriteLine(" ===== Data Gaze ====== ");
                    outputFX.WriteLine(" Target X : " + titikX4);
                    for (int i = 0; i < X15.Count; i++)
                    {
                        outputFX.WriteLine("Gaze X : " + X15[i] * lebar);
                    }
                    outputFX.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                    outputFX.WriteLine(" Target Y: " + titikY5);
                    for (int i = 0; i < Y15.Count; i++)
                    {
                        outputFX.WriteLine("Gaze Y : " + Y15[i] * tinggi);
                    }
                    outputFX.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                    outputFX.WriteLine("error x 15 : " + errx15);
                    outputFX.WriteLine("error y 15 : " + erry15);
                    // ========================================================================
                    outputFX.WriteLine(" ===== Data Gaze ====== ");
                    outputFX.WriteLine(" Target X : " + titikX2);
                    for (int i = 0; i < X16.Count; i++)
                    {
                        outputFX.WriteLine("Gaze X : " + X16[i] * lebar);
                    }
                    outputFX.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                    outputFX.WriteLine(" Target Y: " + titikY5);
                    for (int i = 0; i < Y16.Count; i++)
                    {
                        outputFX.WriteLine("Gaze Y : " + Y16[i] * tinggi);
                    }
                    outputFX.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                    outputFX.WriteLine("error x 16 : " + errx16);
                    outputFX.WriteLine("error y 16 : " + erry16);
                    // ========================================================================
                    outputFX.WriteLine(" ===== Data Gaze ====== ");
                    outputFX.WriteLine(" Target X : " + titikX5);
                    for (int i = 0; i < X17.Count; i++)
                    {
                        outputFX.WriteLine("Gaze X : " + X17[i] * lebar);
                    }
                    outputFX.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                    outputFX.WriteLine(" Target Y: " + titikY5);
                    for (int i = 0; i < Y17.Count; i++)
                    {
                        outputFX.WriteLine("Gaze Y : " + Y17[i] * tinggi);
                    }
                    outputFX.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                    outputFX.WriteLine("error x 17 : " + errx17);
                    outputFX.WriteLine("error y 17 : " + erry17);
                }
                #endregion
                #region Clear List
                X1.Clear(); X2.Clear(); X3.Clear(); X4.Clear(); X5.Clear(); X6.Clear();
                X7.Clear(); X8.Clear(); X9.Clear(); X10.Clear(); X11.Clear(); X12.Clear();
                X13.Clear(); X14.Clear(); X15.Clear(); X16.Clear(); X17.Clear();

                Y1.Clear(); Y2.Clear(); Y3.Clear(); Y4.Clear(); Y5.Clear(); Y6.Clear();
                Y7.Clear(); Y8.Clear(); Y9.Clear(); Y10.Clear(); Y11.Clear(); Y12.Clear();
                Y13.Clear(); Y14.Clear(); Y15.Clear(); Y16.Clear(); Y17.Clear();
                #endregion


                status = true;
            }
            else if (e.KeyCode == Keys.D1)
            {
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Green, titikX1 - 15, titikY1 - 15, 30, 30);
                timer1.Start();
                record = false;
            }
            else if (e.KeyCode == Keys.D2)
            {
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                //g.Clear(Color.Black);
                g.FillEllipse(Brushes.Green, titikX2 - 15, titikY1 - 15, 30, 30);
                timer2.Start();
                record = false;
                //GP.HidupkanGazepoint();
                //work.DoWork += backgroundWorker1_DoWork;
                //work.RunWorkerAsync(); 
            }
            else if (e.KeyCode == Keys.D3)
            {
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Green, titikX3 - 15, titikY1 - 15, 30, 30);
                timer3.Start();
                record = false;
            }
            else if (e.KeyCode == Keys.D4)
            {
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Green, titikX1 - 15, titikY2 - 15, 30, 30);
                timer4.Start();
                record = false;
            }
            else if (e.KeyCode == Keys.T)
            {
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Green, titikX2 - 15, titikY2 - 15, 30, 30);
                timer5.Start();
                record = false;
            }
            else if (e.KeyCode == Keys.D5)
            {
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Green, titikX3 - 15, titikY2 - 15, 30, 30);
                timer6.Start();
                record = false;
            }
            else if (e.KeyCode == Keys.D6)
            {
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Green, titikX1 - 15, titikY3 - 15, 30, 30);
                timer7.Start();
                record = false;
            }
            else if (e.KeyCode == Keys.D7)
            {
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Green, titikX2 - 15, titikY3 - 15, 30, 30);
                timer8.Start();
                record = false;
            }
            else if (e.KeyCode == Keys.D8)
            {
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Green, titikX3 - 15, titikY3 - 15, 30, 30);
                timer9.Start();
                record = false;
            }
            else if (e.KeyCode == Keys.Q)
            {
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Green, titikX4 - 15, titikY4 - 15, 30, 30);
                timer10.Start();
                record = false;
            }
            else if (e.KeyCode == Keys.W)
            {
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Green, titikX2 - 15, titikY4 - 15, 30, 30);
                timer11.Start();
                record = false;
            }
            else if (e.KeyCode == Keys.E)
            {
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Green, titikX5 - 15, titikY4 - 15, 30, 30);
                timer12.Start();
                record = false;
            }
            else if (e.KeyCode == Keys.R)
            {
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Green, titikX4 - 15, titikY2 - 15, 30, 30);
                timer13.Start();
                record = false;
            }
            else if (e.KeyCode == Keys.Y)
            {
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Green, titikX5 - 15, titikY2 - 15, 30, 30);
                timer14.Start();
                record = false;
            }
            else if (e.KeyCode == Keys.U)
            {
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Green, titikX4 - 15, titikY5 - 15, 30, 30);
                timer15.Start();
                record = false;
            }
            else if (e.KeyCode == Keys.I)
            {
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Green, titikX2 - 15, titikY5 - 15, 30, 30);
                timer16.Start();
                record = false;
            }
            else if (e.KeyCode == Keys.O)
            {
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Green, titikX5 - 15, titikY5 - 15, 30, 30);
                timer17.Start();
                record = false;
            }
        }

        private void Record(int x, int y)
        {
            //X.Add(x);
            //Y.Add(y);
        }

        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timesec++;

            if (Hasil[2] != 0)
            {
                X1.Add(Hasil[0]);
                Y1.Add(Hasil[1]);
            }

            if (X1.Count > 4)
            {
                timer1.Stop();
                record = true;
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Red, titikX1 - 15, titikY1 - 15, 30, 30);
                Debug.WriteLine(" ==================== FIXATION ======================= ");
                Debug.WriteLine(" ===== Data Gaze ====== ");
                errx1 = HitungError(X1, titikX1, lebar);
                Debug.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                erry1 = HitungError(Y1, titikY1, tinggi);
                Debug.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                label1.Text = "Error X : " + Math.Round(errx1, 2) + " , " + "\r\n" + "Error Y : " + Math.Round(erry1, 2);
                Debug.WriteLine("error x 1 : " + errx1);
                Debug.WriteLine("error y 1 : " + erry1);
                timesec = 0;
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            timesec2++;

            if (Hasil[2] != 0)
            {
                X2.Add(Hasil[0]);
                Y2.Add(Hasil[1]);
            }

            if (X2.Count > 4)
            {
                timer2.Stop();
                //status = true;
                record = true;
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Red, titikX2 - 15, titikY1 - 15, 30, 30);
                Debug.WriteLine(" ===== Data Gaze ====== ");
                errx2 = HitungError(X2, titikX2, lebar);
                Debug.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                erry2 = HitungError(Y2, titikY1, tinggi);
                Debug.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                label2.Text = "Error X : " + Math.Round(errx2, 2) + " , " + "\r\n" + "Error Y : " + Math.Round(erry2, 2);
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            timesec3++;

            if (Hasil[2] != 0)
            {
                X3.Add(Hasil[0]);
                Y3.Add(Hasil[1]);
            }

            if (X3.Count > 4)
            {
                //status = true;
                record = true;
                timer3.Stop();
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Red, titikX3 - 15, titikY1 - 15, 30, 30);
                Debug.WriteLine(" ===== Data Gaze ====== ");
                errx3 = HitungError(X3, titikX3, lebar);
                Debug.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                erry3 = HitungError(Y3, titikY1, tinggi);
                Debug.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                label3.Text = "Error X : " + Math.Round(errx3, 2) + " , " + "\r\n" + "Error Y : " + Math.Round(erry3, 2);
            }
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {

            while (status == false)
            {
                Hasil = GP.DapatDataGaze();

            }
            GP.MatikanGazepoint();


        }

        private void timer4_Tick(object sender, EventArgs e)
        {
            timesec4++;
            if (Hasil[2] != 0)
            {
                X4.Add(Hasil[0]);
                Y4.Add(Hasil[1]);
            }

            if (X4.Count > 4)
            {
                //status = true;
                record = true;
                timer4.Stop();
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Red, titikX1 - 15, titikY2 - 15, 30, 30);
                Debug.WriteLine(" ===== Data Gaze ====== ");
                errx4 = HitungError(X4, titikX1, lebar);
                Debug.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                erry4 = HitungError(Y4, titikY2, tinggi);
                Debug.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                label4.Text = "Error X : " + Math.Round(errx4, 2) + " , " + "\r\n" + "Error Y : " + Math.Round(erry4, 2);

            }
        }

        private void timer5_Tick(object sender, EventArgs e)
        {
            timesec5++;

            if (Hasil[2] != 0)
            {
                X5.Add(Hasil[0]);
                Y5.Add(Hasil[1]);
            }

            if (X5.Count > 4)
            {
                //status = true;
                record = true;
                timer5.Stop();
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Red, titikX2 - 15, titikY2 - 15, 30, 30);
                Debug.WriteLine(" ===== Data Gaze ====== ");
                errx5 = HitungError(X5, titikX2, lebar);
                Debug.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                erry5 = HitungError(Y5, titikY2, tinggi);
                Debug.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                label5.Text = "Error X : " + Math.Round(errx5, 2) + " , " + "\r\n" + "Error Y : " + Math.Round(erry5, 2);

            }
        }

        private void timer6_Tick(object sender, EventArgs e)
        {
            timesec6++;

            if (Hasil[2] != 0)
            {
                X6.Add(Hasil[0]);
                Y6.Add(Hasil[1]);
            }

            if (X6.Count > 4)
            {
                //status = true;
                record = true;
                timer6.Stop();
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Red, titikX3 - 15, titikY2 - 15, 30, 30);
                Debug.WriteLine(" ===== Data Gaze ====== ");
                errx6 = HitungError(X6, titikX3, lebar);
                Debug.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                erry6 = HitungError(Y6, titikY2, tinggi);
                Debug.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                label6.Text = "Error X : " + Math.Round(errx6, 2) + " , " + "\r\n" + "Error Y : " + Math.Round(erry6, 2);

            }
        }

        private void timer7_Tick(object sender, EventArgs e)
        {
            timesec7++;

            if (Hasil[2] != 0)
            {
                X7.Add(Hasil[0]);
                Y7.Add(Hasil[1]);
            }

            if (X7.Count > 4)
            {
                //status = true;
                record = true;
                timer7.Stop();
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Red, titikX1 - 15, titikY3 - 15, 30, 30);
                Debug.WriteLine(" ===== Data Gaze ====== ");
                errx7 = HitungError(X7, titikX1, lebar);
                Debug.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                erry7 = HitungError(Y7, titikY3, tinggi);
                Debug.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                label7.Text = "Error X : " + Math.Round(errx7, 2) + " , " + "\r\n" + "Error Y : " + Math.Round(erry7, 2);

            }
        }

        private void timer8_Tick(object sender, EventArgs e)
        {
            timesec8++;

            if (Hasil[2] != 0)
            {
                X8.Add(Hasil[0]);
                Y8.Add(Hasil[1]);
            }

            if (X8.Count > 4)
            {
                //status = true;
                record = true;
                timer8.Stop();
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Red, titikX2 - 15, titikY3 - 15, 30, 30);
                Debug.WriteLine(" ===== Data Gaze ====== ");
                errx8 = HitungError(X8, titikX2, lebar);
                Debug.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                erry8 = HitungError(Y8, titikY3, tinggi);
                Debug.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                label8.Text = "Error X : " + Math.Round(errx8, 2) + " , " + "\r\n" + "Error Y : " + Math.Round(erry8, 2);

            }
        }

        private void timer9_Tick(object sender, EventArgs e)
        {
            timesec9++;

            if (Hasil[2] != 0)
            {
                X9.Add(Hasil[0]);
                Y9.Add(Hasil[1]);
            }

            if (X9.Count > 4)
            {
                //status = true;
                record = true;
                timer9.Stop();
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Red, titikX3 - 15, titikY3 - 15, 30, 30);
                Debug.WriteLine(" ===== Data Gaze ====== ");
                errx9 = HitungError(X9, titikX3, lebar);
                Debug.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                erry9 = HitungError(Y9, titikY3, tinggi);
                Debug.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                label9.Text = "Error X : " + Math.Round(errx9, 2) + " , " + "\r\n" + "Error Y : " + Math.Round(erry9, 2);

            }
        }


        private double HitungError(List<double> gaze, int target, int size)
        {
            double rata2;
            double hasilerror = 0.00;
            double[] _gaze = gaze.ToArray();

            Debug.WriteLine("titik target : " + target);
            for (int i = 0; i < _gaze.Length; i++)
            {
                hasilerror += Math.Sqrt(Math.Pow((_gaze[i] * size) - target, 2));
                Debug.WriteLine("gaze : " + _gaze[i] * size);
            }

            rata2 = hasilerror / _gaze.Length;

            return rata2;
        }

        private void timer10_Tick(object sender, EventArgs e)
        {
            timesec10++;

            if (Hasil[2] != 0)
            {
                X10.Add(Hasil[0]);
                Y10.Add(Hasil[1]);
            }

            if (X10.Count > 4)
            {
                timer10.Stop();
                record = true;
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Red, titikX4 - 15, titikY4 - 15, 30, 30); // Titik Dalam 1
                Debug.WriteLine(" ===== Data Gaze ====== ");
                errx10 = HitungError(X10, titikX4, lebar);
                Debug.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                erry10 = HitungError(Y10, titikY4, tinggi);
                Debug.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                label10.Text = "Error X : " + Math.Round(errx10, 2) + " , " + "\r\n" + "Error Y : " + Math.Round(erry10, 2);
                Debug.WriteLine("error 10 : " + errx10);

            }
        }

        private void timer11_Tick(object sender, EventArgs e)
        {
            timesec11++;

            if (Hasil[2] != 0)
            {
                X11.Add(Hasil[0]);
                Y11.Add(Hasil[1]);
            }

            if (X11.Count > 4)
            {
                timer11.Stop();
                record = true;
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Red, titikX2 - 15, titikY4 - 15, 30, 30); // Titik Dalam 2
                Debug.WriteLine(" ===== Data Gaze ====== ");
                errx11 = HitungError(X11, titikX2, lebar);
                Debug.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                erry11 = HitungError(Y11, titikY4, tinggi);
                Debug.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                label11.Text = "Error X : " + Math.Round(errx11, 2) + " , " + "\r\n" + "Error Y : " + Math.Round(erry11, 2);
                Debug.WriteLine("error 11 : " + errx11);

            }
        }

        private void timer12_Tick(object sender, EventArgs e)
        {
            timesec12++;

            if (Hasil[2] != 0)
            {
                X12.Add(Hasil[0]);
                Y12.Add(Hasil[1]);
            }

            if (X12.Count > 4)
            {
                timer12.Stop();
                record = true;
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Red, titikX5 - 15, titikY4 - 15, 30, 30); // Titik Dalam 3
                Debug.WriteLine(" ===== Data Gaze ====== ");
                errx12 = HitungError(X12, titikX5, lebar);
                Debug.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                erry12 = HitungError(Y12, titikY4, tinggi);
                Debug.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                label12.Text = "Error X : " + Math.Round(errx12, 2) + " , " + "\r\n" + "Error Y : " + Math.Round(erry12, 2);
                Debug.WriteLine("error 12 : " + errx12);

            }
        }

        private void timer13_Tick(object sender, EventArgs e)
        {
            timesec13++;

            if (Hasil[2] != 0)
            {
                X13.Add(Hasil[0]);
                Y13.Add(Hasil[1]);
            }

            if (X13.Count > 4)
            {
                timer13.Stop();
                record = true;
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Red, titikX4 - 15, titikY2 - 15, 30, 30); // Titik Dalam 4
                Debug.WriteLine(" ===== Data Gaze ====== ");
                errx13 = HitungError(X13, titikX4, lebar);
                Debug.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                erry13 = HitungError(Y13, titikY2, tinggi);
                Debug.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                label13.Text = "Error X : " + Math.Round(errx13, 2) + " , " + "\r\n" + "Error Y : " + Math.Round(erry13, 2);
                Debug.WriteLine("error 13 : " + errx13);

            }
        }

        private void timer14_Tick(object sender, EventArgs e)
        {
            timesec14++;

            if (Hasil[2] != 0)
            {
                X14.Add(Hasil[0]);
                Y14.Add(Hasil[1]);
            }

            if (X14.Count > 4)
            {
                timer14.Stop();
                record = true;
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Red, titikX5 - 15, titikY2 - 15, 30, 30); // Titik Dalam 6
                Debug.WriteLine(" ===== Data Gaze ====== ");
                errx14 = HitungError(X14, titikX5, lebar);
                Debug.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                erry14 = HitungError(Y14, titikY2, tinggi);
                Debug.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                label14.Text = "Error X : " + Math.Round(errx14, 2) + " , " + "\r\n" + "Error Y : " + Math.Round(erry14, 2);
                Debug.WriteLine("error 14 : " + errx14);

            }
        }

        private void timer15_Tick(object sender, EventArgs e)
        {
            timesec15++;

            if (Hasil[2] != 0)
            {
                X15.Add(Hasil[0]);
                Y15.Add(Hasil[1]);
            }

            if (X15.Count > 4)
            {
                timer15.Stop();
                record = true;
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Red, titikX4 - 15, titikY5 - 15, 30, 30); // Titik Dalam 7
                Debug.WriteLine(" ===== Data Gaze ====== ");
                errx15 = HitungError(X15, titikX4, lebar);
                Debug.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                erry15 = HitungError(Y15, titikY5, tinggi);
                Debug.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                label15.Text = "Error X : " + Math.Round(errx15, 2) + " , " + "\r\n" + "Error Y : " + Math.Round(erry15, 2);
                Debug.WriteLine("error 15 : " + errx15);

            }
        }

        private void timer16_Tick(object sender, EventArgs e)
        {
            timesec16++;

            if (Hasil[2] != 0)
            {
                X16.Add(Hasil[0]);
                Y16.Add(Hasil[1]);
            }

            if (X16.Count > 4)
            {
                timer16.Stop();
                record = true;
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Red, titikX2 - 15, titikY5 - 15, 30, 30); // Titik Dalam 8
                Debug.WriteLine(" ===== Data Gaze ====== ");
                errx16 = HitungError(X16, titikX2, lebar);
                Debug.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                erry16 = HitungError(Y16, titikY5, tinggi);
                Debug.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                label16.Text = "Error X : " + Math.Round(errx16, 2) + " , " + "\r\n" + "Error Y : " + Math.Round(erry16, 2);
                Debug.WriteLine("error 16 : " + errx16);

            }
        }

        private void timer17_Tick(object sender, EventArgs e)
        {
            timesec17++;

            if (Hasil[2] != 0)
            {
                X17.Add(Hasil[0]);
                Y17.Add(Hasil[1]);
            }

            if (X17.Count > 4)
            {
                timer17.Stop();
                record = true;
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Red, titikX5 - 15, titikY5 - 15, 30, 30); // Titik Dalam 9
                Debug.WriteLine(" ===== Data Gaze ====== ");
                errx17 = HitungError(X17, titikX5, lebar);
                Debug.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                erry17 = HitungError(Y17, titikY5, tinggi);
                Debug.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                label17.Text = "Error X : " + Math.Round(errx17, 2) + " , " + "\r\n" + "Error Y : " + Math.Round(erry17, 2);
                Debug.WriteLine("error 17 : " + errx17);

            }
        }


    }
}
