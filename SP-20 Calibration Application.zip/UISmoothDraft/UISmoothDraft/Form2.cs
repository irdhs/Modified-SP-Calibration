﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;

using MathNet;
using MathNet.Numerics;

namespace UISmoothDraft
{
    public partial class Form2 : Form
    {
        Gazepoint GP = new Gazepoint();

        #region Setting graphic form
        static int lebar = Screen.PrimaryScreen.Bounds.Width;
        static int tinggi = Screen.PrimaryScreen.Bounds.Height;
        Bitmap bmp = new Bitmap(lebar, tinggi);
        Bitmap bmp2 = new Bitmap(lebar, tinggi);
        Graphics g;
        #endregion

        #region Setting drawing lingkaran kalibrasi
        int radius = tinggi / 2 - 50; // tentukan radius lingakaran
        int centerx = lebar / 2; // tentukan titik tengah posisi x
        int centery = tinggi / 2; // tentukan titik tengah posisi y
        int angle = 0;

        Point titikawal;
        PointF titikfloat;
        Point titik;
        int timecs;

        List<int> TargetX = new List<int>();
        List<int> TargetY = new List<int>();
        List<int> time = new List<int>();

        int[] targetx_array;
        int[] targety_array;
        int[] waktu_target;

        double[] gaze_x;
        double[] gaze_y;
        double[] time_gaze;

        int[][] DataTarget;
        double[][] Data;
        List<Point> target = new List<Point>();
        #endregion

        #region Koord Mouse di PictureBox
        int _x;
        int _y; 
        #endregion

        #region BackgroundWorker
        BackgroundWorker work = new BackgroundWorker();
        List<int> X = new List<int>();
        List<int> Y = new List<int>();
        int[] dataX;
        int[] DataInput;
        #endregion

        #region Gazepoint
        bool flaglingkaran = false;
        bool exit_state = false;
        double[] Hasil = new double[4];
        double[] Output = new double[4];

        int ix = 0;
        int jumlahSampel = 300;
        int jumlahData = 0;

        List<double> TitikX = new List<double>();
        List<double> TitikY = new List<double>();
        List<double> Kondisi = new List<double>();
        List<double> Waktu = new List<double>();

        double[][] OutFilter;
        FitEllipse EllipseFit = new FitEllipse();
        double[,] EllipseParam;
        static int wind1 = 15;
        int halfwind = (wind1 + 1) / 2;

        double aX, bX, aY, bY;

        double[,] ParameterEllipse = new double[6, 1]; 

        #endregion

        Form1 fr1;

        public Form2(Form1 fr_1)
        {

            InitializeComponent();
            fr1 = fr_1;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            int w = Screen.PrimaryScreen.Bounds.Width;
            int h = Screen.PrimaryScreen.Bounds.Height;
            this.Location = new Point(0, 0);
            this.Size = new Size(w, h);
            button2.BringToFront();

            //GP.HidupkanGazepoint();

            g = Graphics.FromImage(bmp);
            pictureBox1.Image = bmp;
            g.Clear(Color.White);
            titikawal = (Point)LingkaranKecil(0, radius, centerx, centery);
            g.DrawEllipse(new Pen(Color.Black, 1f), centerx - radius, centery - radius, radius * 2, radius * 2);
            g.FillEllipse(Brushes.Red, titikawal.X - 15, titikawal.Y - 15, 30, 30);
        }

        private float[] Circle(int angleIn, int radius, int centerx, int centery)
        {
            float[] coord = new float[2];
            angleIn %= 360;
            angleIn *= 1;

            if (angleIn >= 0 && angleIn <= 180)
            {
                coord[0] = centerx + (float)(radius * Math.Sin(Math.PI * angleIn / 180));
                coord[1] = centery - (float)(radius * Math.Cos(Math.PI * angleIn / 180));
            }
            else
            {
                coord[0] = centerx - (float)(radius * -Math.Sin(Math.PI * angleIn / 180));
                coord[1] = centery - (float)(radius * Math.Cos(Math.PI * angleIn / 180));
            }

            return coord;
        }

        public Point LingkaranKecil(int sudut, int ukuran, int pusatx, int pusaty)
        {
            Point point1 = new Point((int)Circle(angle, radius, centerx, centery)[0], (int)Circle(angle, radius, centerx, centery)[1]);
            return point1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
         
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //FormBorderStyle = FormBorderStyle.None;
            //WindowState = FormWindowState.Maximized;
            //TopMost = true;
            timecs = 0;
            
            timer1.Start();
            
            work.DoWork += backgroundWorker1_DoWork;
            work.RunWorkerAsync();
        }

        private void Form2_KeyDown(object sender, KeyEventArgs e)
        {
            this.Close();
            /*
            if (e.KeyCode == Keys.Escape)
            {
                FormBorderStyle = FormBorderStyle.Sizable;
                WindowState = FormWindowState.Normal;
                TopMost = false;
            }*/
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            g = Graphics.FromImage(bmp);
            g.Clear(Color.White);
            titikfloat = new PointF(Circle(angle, radius, centerx, centery)[0], Circle(angle, radius, centerx, centery)[1]);
            titik = LingkaranKecil(angle, radius, centerx, centery);
            timecs++;
            pictureBox1.Image = bmp;

            g.DrawEllipse(new Pen(Color.Black, 1f), centerx - radius, centery - radius, radius * 2, radius * 2);
            g.FillEllipse(Brushes.Red, titik.X - 15, titik.Y - 15, 30, 30);
            g.Dispose();

            if (flaglingkaran == true) //if (TargetX.Count == 80)
            {
                //timer1.Stop();
                //exit_state = true;
                jumlahData = TitikX.Count;
                Debug.WriteLine(" jumlah data : " + jumlahData);

                #region kirim data ke form 1 untuk memunculkan grafik versi 1
                /*
                targetx_array = TargetX.ToArray();
                time_array = time.ToArray();
                Data = new int[targetx_array.Length][];
                for (int i = 0; i < targetx_array.Length; i++)
                {
                    Data[i] = new int[2];

                    Data[i][0] = time_array[i];
                    Data[i][1] = targetx_array[i];
                }
                fr1.Item(Data);
                */
                #endregion

                #region kirim data ke form 1 untuk memunculkan grafik versi 2
                /*
                targetx_array = TargetX.ToArray();
                time_array = time.ToArray();
                Data = new int[targetx_array.Length][];
                for (int i = 0; i < targetx_array.Length; i++)
                {
                    Data[i] = new int[2];

                    Data[i][0] = time_array[i];
                    Data[i][1] = targetx_array[i];
                }
                fr1.Item(Data);
                
                DataInput = new int[dataX.Length];
                for(int i = 0; i < dataX.Length; i++)
                {
                    //Debug.WriteLine("data X [" + i + "] : "  + dataX[i]);
                    DataInput[i] = dataX[i];
                }
                fr1.Item2(DataInput);
                */
                #endregion
                
                //Thread.Sleep(1000);
                //this.Close();
            }
            else
            {
                if (angle == 360)
                {
                    angle = 0;
                }
                else
                {
                    angle++;
                    //Thread.Sleep(5);
                }
            }
            //Debug.WriteLine(timecs + " Time : " + (timecs-1)*timer1.Interval + " X : " + titikfloat.X + " Y : " + titikfloat.Y);

        }
        
        private void button3_Click(object sender, EventArgs e)
        {
            targetx_array = TargetX.ToArray();
            targety_array = TargetY.ToArray();
            waktu_target = time.ToArray();
            //DataTarget = new int[targetx_array.Length][];
            //for (int i = 0; i < targetx_array.Length; i++)
            DataTarget = new int[OutFilter.Length][];
            for (int i = 0; i < OutFilter.Length; i++)
            {
                DataTarget[i] = new int[3];
                /*
                DataTarget[i][0] = waktu_target[i];
                DataTarget[i][1] = targetx_array[i];
                DataTarget[i][2] = targety_array[i];
                 */
                DataTarget[i][0] = i;
                DataTarget[i][1] = (int)OutFilter[i][2];
                DataTarget[i][2] = (int)OutFilter[i][3];

            } 

            gaze_x = TitikX.ToArray();
            gaze_y = TitikY.ToArray();
            time_gaze = Waktu.ToArray();
            Data = new double[OutFilter.Length][];
            

            for(int i = 0; i < OutFilter.Length; i++)
            {
                Data[i] = new double[3];
                
                Data[i][0] = i;
                Data[i][1] = (int)(OutFilter[i][0] * 1366);
                Data[i][2] = (int)(OutFilter[i][1] * 768);

                //Debug.WriteLine(" Time Array : " + i + " " + Data[i][0]);
            }

            #region Tulis File Output
            /*
            using (StreamWriter outputTarget = new StreamWriter("C:\\Users\\Lenovo\\Desktop\\Experiment Filter\\Output Pixel.txt", true))
            {
                outputTarget.WriteLine("");
                for (int i = 0; i < OutFilter.Length; i++)
                {
                    //outputTarget.WriteLine("Gaze X : " + Data[i][1]);
                    outputTarget.WriteLine("Gaze X : " + OutFilter[i][0] * 1366);
                }

                for (int i = 0; i < OutFilter.Length; i++)
                {
                    //outputTarget.WriteLine("Target X : " + DataTarget[i][1]);
                    outputTarget.WriteLine("Target X : " + OutFilter[i][2]);
                }
            }
            */
            #endregion

            Chart Grafik = new Chart();
            //Grafik.AddItem(TargetX);
            //Grafik.AddItem(time);
            Grafik.Item(Data);
            Grafik.Item2(DataTarget);
            Grafik.Show();
            //foreach(int valuex in TargetX)
            //{
                //Debug.WriteLine("Target X : " + valuex);
            //}
            
        }

        public double[] MunculkanNilai()
        {
            while (exit_state == false)
            {
                //Thread.Sleep(15); //pakai ini yg utama
                //Thread.Sleep(2);
                Hasil = GP.DapatDataGaze();
                if(Hasil[2] != 0)
                {
                    TargetX.Add(titik.X);
                    TargetY.Add(titik.Y);
                    //time.Add((timecs - 1) * timer1.Interval);
                    time.Add(ix);
                    TitikX.Add(Hasil[0]);
                    TitikY.Add(Hasil[1]);
                    //Waktu.Add(Hasil[3]);
                    Waktu.Add(ix);
                }

                //Kondisi.Add(Hasil[2]);
                
                //Debug.WriteLine(ix + " X : " + Hasil[0]);
                //Debug.WriteLine(ix + " Y : " + Hasil[1]); 
                //if(TitikX.Count == jumlahSampel)
                if (TitikX.Count > jumlahSampel)
                {
                    flaglingkaran = true;
                    timer1.Stop();
                    exit_state = true; 
                }
                //Debug.WriteLine(ix + "Time : " + Hasil[3]);
                ix++;
            }
            double[] X = TitikX.ToArray();
            double[] Y = TitikY.ToArray();
            int[] X_t = TargetX.ToArray();
            int[] Y_t = TargetY.ToArray();

            OutFilter = filterMA(wind1, halfwind, X, Y, X_t, Y_t);

            //int[] X_input = new int[OutFilter.Length];
            //int[] Y_input = new int[OutFilter.Length];
            //int[] X_output = new int[OutFilter.Length];
            //int[] Y_output = new int[OutFilter.Length];

            double[] X_input = new double[OutFilter.Length];
            double[] Y_input = new double[OutFilter.Length];
            double[] X_output = new double[OutFilter.Length];
            double[] Y_output = new double[OutFilter.Length];

            for (int i = 0; i < OutFilter.Length; i++)
            {
                X_input[i] = OutFilter[i][0];
                Y_input[i] = OutFilter[i][1];
                X_output[i] = OutFilter[i][2] / lebar;
                Y_output[i] = OutFilter[i][3] / tinggi;
            }

            //Linear Regression
            
            Tuple<double,double> pX = Fit.Line(X_input, X_output); //%%%%%%%%%%%%%%%%%%%%%%
            aX = pX.Item1;
            bX = pX.Item2;

            Tuple<double, double> pY = Fit.Line(Y_input, Y_output); //%%%%%%%%%%%%%%%%%%%%%%
            aY = pY.Item1;
            bY = pY.Item2;
            
           //Debug.WriteLine(" a : " + a);
           //Debug.WriteLine(" b : " + b);
           
            //Ellipse Regression
            //EllipseParamX = EllipseFit.Fit(X_input, X_output); //%%%%%%%%%%%%%%%%%%%%%%%%
            //EllipseParamY = EllipseFit.Fit(Y_input, Y_output); //%%%%%%%%%%%%%%%%%%%%%%%%

            //Debug.WriteLine(" Ellipse Parameter : " + EllipseParam.Length + " Parameter : " + EllipseParam);
           /*
            Debug.WriteLine(" a : " + EllipseParam[0,0]);
            Debug.WriteLine(" b : " + EllipseParam[1, 0]);
            Debug.WriteLine(" c : " + EllipseParam[2, 0]);
            Debug.WriteLine(" d : " + EllipseParam[3, 0]);
            Debug.WriteLine(" e : " + EllipseParam[4, 0]);
            Debug.WriteLine(" f : " + EllipseParam[5, 0]);
            Debug.WriteLine(" OutFilter Length : " + OutFilter.Length + " OutFilter : " + OutFilter);
            */
            //HasiljumlahData = TitikX.Count;
            //Debug.WriteLine(" jumlah data : " + jumlahData);
            Debug.WriteLine("jumlahData Titik X : " + TitikX.Count);

            return Hasil;
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            GP.HidupkanGazepoint();
            Output = MunculkanNilai();
            GP.MatikanGazepoint();

            #region data percobaan
            /*
            int[] a = new int[8] {683, 688, 697, 703, 708, 720, 882, 850};
            dataX = new int[a.Length];

            for (int i = 0; i < a.Length; i++)
            {
                Thread.Sleep(1000);
                dataX[i] = a[i];
                //Thread.Sleep(1000);
                Debug.WriteLine("b " + i + " : " + dataX[i]);
            }



            X.Add(_x);
            Y.Add(_y);

            Debug.WriteLine("_X : " + _x);

            //dataX = X.ToArray();
            */
            #endregion
        }

        private void backgroundWorker1_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            
        }

        private void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {

        }

        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
        }

        public double[][] filterMA(int window, int halfwindow, double[] nilaix, double[] nilaiy, int[] nilaiPx, int[] nilaiPy)
        {
            double[] filtermean_x1 = new double[nilaix.Length];
            double[] filtermean_y1 = new double[nilaiy.Length];
            List<double> xs = new List<double>();
            List<double> ys = new List<double>();
            List<int> px = new List<int>();
            List<int> py = new List<int>();

            for (int ind = halfwindow - 1; ind < nilaix.Length - (halfwindow - 1); ind++)
            //for (int ind = 0; ind < SlideWindow; ind++)
            {

                double meanx = 0;
                double meany = 0;

                for (int j = 1 - halfwindow; j < halfwindow; j++)
                {
                    meanx += nilaix[ind + j];
                    meany += nilaiy[ind + j];

                }

                filtermean_x1[ind] = meanx / window;
                filtermean_y1[ind] = meany / window;

                xs.Add(filtermean_x1[ind]);
                ys.Add(filtermean_y1[ind]);

                px.Add(nilaiPx[ind]);
                py.Add(nilaiPy[ind]);
            
            }

            double[] Xm = xs.ToArray(); double[] Ym = ys.ToArray();
            int[] Tx = px.ToArray(); int[] Ty = py.ToArray();
            double[][] Hasil = new double[Xm.Length][];

            for (int i = 0; i < Xm.Length; i++)
            {
                Hasil[i] = new double[4];
                Hasil[i][0] = Xm[i];
                Hasil[i][1] = Ym[i];
                Hasil[i][2] = Tx[i];
                Hasil[i][3] = Ty[i];
            }

            return Hasil;
        }

        public double Correlation(double[] array1, double[] array2)
        {
            double[] array_xy = new double[array1.Length];
            double[] array_xp2 = new double[array1.Length];
            double[] array_yp2 = new double[array1.Length];

            for (int i = 0; i < array1.Length; i++)
                array_xy[i] = array1[i] * array2[i];
            for (int i = 0; i < array1.Length; i++)
                array_xp2[i] = Math.Pow(array1[i], 2.0);
            for (int i = 0; i < array1.Length; i++)
                array_yp2[i] = Math.Pow(array2[i], 2.0);

            double sum_x = 0;
            double sum_y = 0;
            foreach (double n in array1)
                sum_x += n;
            foreach (double n in array2)
                sum_y += n;
            double sum_xy = 0;
            foreach (double n in array_xy)
                sum_xy += n;
            double sum_xpow2 = 0;
            foreach (double n in array_xp2)
                sum_xpow2 += n;
            double sum_ypow2 = 0;
            foreach (double n in array_yp2)
                sum_ypow2 += n;
            double Ex2 = Math.Pow(sum_x, 2.00);
            double Ey2 = Math.Pow(sum_y, 2.00);

            return (array1.Length * sum_xy - sum_x * sum_y) / Math.Sqrt((array1.Length * sum_xpow2 - Ex2) * (array1.Length * sum_ypow2 - Ey2));
        }

        private void button4_Click(object sender, EventArgs e)
        {
            
            ValidasiSP Valid = new ValidasiSP();
            Valid.LinearReg(aX, bX, aY, bY);
            //Valid.ParamEllipseX(EllipseParam);
            Valid.Show();
        }
    
    // End
    }
}
