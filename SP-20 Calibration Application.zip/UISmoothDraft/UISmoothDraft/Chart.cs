﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UISmoothDraft
{
    public partial class Chart : Form
    {
        List<int> Target_X = new List<int>();
        List<int> a;
        double[][] b;
        int[][] c;

        public Chart()
        {
            /*
            Form2 Data2 = new Form2();
            Data2.SendDATA(this.TargetX);

            foreach (int valuex in TargetX)
            {
                Debug.WriteLine("Target : " + valuex);
            }
            Debug.WriteLine(TargetX.Count);
            */
            InitializeComponent();
    
        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        public List<int> AddItem(List<int> x)
        {
            //foreach (int valuex in x)
            //{
              //Debug.WriteLine("Target X : " + valuex);
            //}
            //Debug.WriteLine("target_x : " + x.Count);
            return a;
        }

        public double[][] Item(double[][] x)
        {
            b = new double[x.Length][];
            for (int i = 0; i < x.Length; i++ )
            {
                b[i] = new double[3];
                b[i][0] = x[i][0];
                b[i][1] = x[i][1];
                b[i][2] = x[i][2];
                //Debug.WriteLine(" b" + i + " [0] " + b[i][0]);
            }
            Debug.WriteLine(" Gaze Length : " + b.Length);
            return b;
        }

        public int[][] Item2(int[][] x)
        {
            c = new int[x.Length][];
            for (int i = 0; i < x.Length; i++)
            {
                c[i] = new int[3];
                c[i][0] = x[i][0];
                c[i][1] = x[i][1];
                c[i][2] = x[i][2];
                //Debug.WriteLine(" c" + i + " : " + c[i]);
            }
            Debug.WriteLine(" Target Length : " + c.Length);
            return c;
        }

        double function(double x)
        {
            return(Math.Pow(x, 2) + 2 * Math.Sin(2*x));
        }

        private void Chart_Load(object sender, EventArgs e)
        {
      
            chart1.ChartAreas[0].AxisY.ScaleView.Zoom(0, 1200);
            chart1.ChartAreas[0].AxisX.ScaleView.Zoom(0, 1200);
            chart1.Series[0].Color = Color.Red;

            chart1.Series[1].Color = Color.Blue;

            //chart1.ChartAreas[0].AxisX.Minimum = 0;
            chart1.ChartAreas[0].CursorX.IsUserEnabled = true;
            chart1.ChartAreas[0].CursorX.IsUserSelectionEnabled = true;
            chart1.ChartAreas[0].AxisX.ScaleView.Zoomable = true;

            for(int i=0; i<b.Length;i++)
            {
                chart1.Series[0].Points.AddXY(b[i][2], c[i][2]);  //xinput terhadap xtarget
                //chart1.Series[0].Points.AddXY(b[i][1], b[i][2]);
                //chart1.Series[0].Points.AddXY(b[i][0], b[i][1]); // data gaze terhadap waktu
                //chart1.Series[0].Points.AddXY(i, 2);
                chart1.Series[0].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Point;
                
            }

            // grafik y :
            for (int i = 0; i < c.Length; i++)
            {
                //chart1.Series[1].Points.AddXY(b[i][2], c[i][2]); // yinput terhadap ytarget
                //chart1.Series[1].Points.AddXY(c[i][2], c[i][2]);
                //chart1.Series[1].Points.AddXY(c[i][0], c[i][2]); // data target terhadap waktu
                chart1.Series[1].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            }

            /*
            for(int i = 0; i < c.Length; i++)
            {
                chart1.Series[1].Points.AddXY(c[i][0], c[i][1]);
                chart1.Series[1].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Point;
            }*/

            // %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

            /*
            for (int i = 0; i < c.Length; i++)
            {
                chart1.Series[1].Points.AddXY(i*1000, c[i]);
                chart1.Series[1].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            }*/
        }
    }
}
