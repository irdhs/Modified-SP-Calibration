﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UISmoothDraft
{
    class Normalisasi
    {
        #region Setting graphic form
        static double lebar = System.Windows.Forms.Screen.PrimaryScreen.Bounds.Width;
        static double tinggi = System.Windows.Forms.Screen.PrimaryScreen.Bounds.Height;
        #endregion

        public double NormalisasiX(int inp)
        {
            double outp;
            outp = inp / lebar;
            return outp;
        }

        public double NormalisasiY(int inp)
        {
            double outp;
            outp = inp / tinggi;
            return outp;
        }

        public double DeNormalisasiX(double inp)
        {
            int outp;
            outp = (int)(inp * lebar);
            return outp;
        }

        public double DeNormalisasiY(double inp)
        {
            int outp;
            outp = (int)(inp * tinggi);
            return outp;
        }

    }
}
