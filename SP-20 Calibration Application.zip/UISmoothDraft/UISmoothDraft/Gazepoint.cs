﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.IO;
using System.Media;
using System.Net;
using System.Net.Sockets;
using System.Xml.Linq;
using Microsoft.Win32;

namespace UISmoothDraft
{
    class Gazepoint
    {
        #region Gazepoint GP3 Variabel
        TcpClient gp3_client;
        NetworkStream data_feed;
        StreamWriter data_write;
        string serverReply = string.Empty;
        const int ServerPort = 4242;
        const string ServerAddr = "127.0.0.1";
        #endregion

        #region variabel
        double[] result;
        double[] hasil = new double[3];
        #endregion

        public void HidupkanGazepoint()
        {
            try
            {
                gp3_client = new TcpClient(ServerAddr, ServerPort);
                Debug.WriteLine("Connection Establish");
            }

            catch (Exception ex)
            {
                Debug.WriteLine("Failed to connect with error: {0}", ex);
            }


            //load the read and write streams
            data_feed = gp3_client.GetStream();
            data_write = new StreamWriter(data_feed);

            //Setup the data records
            data_write.Write("<SET ID=\"ENABLE_SEND_TIME\" STATE=\"1\" />\r\n");
            data_write.Write("<SET ID=\"ENABLE_SEND_POG_FIX\" STATE=\"1\" />\r\n");
            data_write.Write("<SET ID=\"ENABLE_SEND_DATA\" STATE=\"1\" />\r\n");

            //Flush the buffer out the socket
            data_write.Flush();
        }

        public void MatikanGazepoint()
        {
            Debug.WriteLine("Connection Close");
            data_write.Close();
            data_feed.Close();
            gp3_client.Close();
        }

        public double[] DapatDataGaze()
        {
            //result = new double[3];

            while (true)
            {
                result = new double[4];
                int ch = data_feed.ReadByte();

                if (ch != -1)
                {
                    serverReply += (char)ch;
                }

                //find string terminator("\r\n")
                if (serverReply.IndexOf("\r\n") != -1)
                {
                    //Only process data Record <REC.../>
                    if (serverReply.IndexOf("<REC") != -1)
                    {
                        double fpogx;
                        double fpogy;
                        double fpog_valid;
                        double _waktu;


                        XElement sessionXML = XElement.Parse(serverReply);

                        var validFixation = sessionXML.Attribute("FPOGV").Value;
                        fpog_valid = Convert.ToDouble(validFixation);
                        //Debug.WriteLine("Valid_ID" , validFixation);

                        var xPOG = sessionXML.Attribute("FPOGX").Value;
                        var yPOG = sessionXML.Attribute("FPOGY").Value;


                        fpogx = Math.Round(Convert.ToDouble(xPOG), 3);
                        fpogy = Math.Round(Convert.ToDouble(yPOG), 3);

                        var _waktu_ = sessionXML.Attribute("TIME").Value;
                        _waktu = Convert.ToDouble(_waktu_);

                        result[0] = fpogx;
                        result[1] = fpogy;
                        result[2] = fpog_valid;
                        result[3] = _waktu;

                        #region debug
                        //Debug.WriteLine("Time :" + _waktu);

                        //Debug.WriteLine("Time elapsed :" + timer.Elapsed.TotalMilliseconds);

                        //Debug.WriteLine("result[2] : {0}", result[2]);
                        //}
                        //result[3] = validFixation;
                        //Debug.WriteLine("fpogx : {0}", fpogx);
                        #endregion

                        //Debug.WriteLine("X : " + result[0]);

                        serverReply = string.Empty;

                        return result;
                    }
                    serverReply = string.Empty;
                }

            }
        }

        public void Calibration_Point()
        {
            gp3_client = new TcpClient(ServerAddr, ServerPort);
            data_feed = gp3_client.GetStream();
            data_write = new StreamWriter(data_feed);
            data_write.Write("<SET ID=\"CALIBRATE_SHOW\" STATE=\"1\" />\r\n");
            data_write.Write("<SET ID=\"CALIBRATE_START\" STATE=\"1\" />\r\n");
            data_write.Write("<SET ID=\"ENABLE_SEND_DATA\" STATE=\"1\" />\r\n");
            data_write.Flush();
        }

        //end program
    }
}
