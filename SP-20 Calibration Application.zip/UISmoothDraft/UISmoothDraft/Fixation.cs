﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UISmoothDraft
{
    public partial class Fixation : Form
    {
        Gazepoint GP = new Gazepoint();
        Form3 fr3 = new Form3();

        public Fixation()
        {
            InitializeComponent();
        }

        private void Fixation_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                this.Close();
                fr3.Show();

            }
            else if (e.KeyCode == Keys.Space)
            {
                GP.Calibration_Point();
            }
        }

        private void Fixation_Load(object sender, EventArgs e)
        {
            int w = Screen.PrimaryScreen.Bounds.Width;
            int h = Screen.PrimaryScreen.Bounds.Height;
            this.Location = new Point(0, 0);
            this.Size = new Size(w, h);
        }
    }
}
