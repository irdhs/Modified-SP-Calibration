﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;

namespace UISmoothDraft
{
    public partial class ValidasiSP : Form
    {

        #region Setting graphic form
        static int lebar = Screen.PrimaryScreen.Bounds.Width;
        static int tinggi = Screen.PrimaryScreen.Bounds.Height;
        Bitmap bmp = new Bitmap(lebar, tinggi);
        Bitmap bmp2 = new Bitmap(lebar, tinggi);
        Graphics g;
        #endregion

        #region Setting drawing lingkaran kalibrasi
        int radius = tinggi / 2 - 50; // tentukan radius lingakaran
        int centerx = lebar / 2; // tentukan titik tengah posisi x
        int centery = tinggi / 2; // tentukan titik tengah posisi y
        int angle = 0;

        //lingkaran luar
        static int titikX1 = (int)(lebar * 0.1);
        static int titikX2 = (int)(lebar * 0.5);
        static int titikX3 = (int)(lebar * 0.9);
        static int titikY1 = (int)(tinggi * 0.1);
        static int titikY2 = (int)(tinggi * 0.5);
        static int titikY3 = (int)(tinggi * 0.9);

        //lingkaran dalam
        static int titikX4 = (int)(lebar * 0.4);
        static int titikX5 = (int)(lebar * 0.6);
        static int titikY4 = (int)(tinggi * 0.4);
        static int titikY5 = (int)(tinggi * 0.6);

        #endregion

        #region koordinat titik
        int timesec = 0;
        int timesec2 = 0, timesec3 = 0, timesec4 = 0, timesec5 = 0;
        int timesec6 = 0, timesec7 = 0, timesec8 = 0, timesec9 = 0;
        int timesec10 = 0, timesec11 = 0, timesec12 = 0, timesec13 = 0;
        int timesec14 = 0, timesec15 = 0, timesec16 = 0, timesec17 = 0;
        int a;
        int b;
        List<double> X1 = new List<double>();
        List<double> X2 = new List<double>();
        List<double> X3 = new List<double>();
        List<double> X4 = new List<double>();
        List<double> X5 = new List<double>();
        List<double> X6 = new List<double>();
        List<double> X7 = new List<double>();
        List<double> X8 = new List<double>();
        List<double> X9 = new List<double>();
        List<double> Y1 = new List<double>();
        List<double> Y2 = new List<double>();
        List<double> Y3 = new List<double>();
        List<double> Y4 = new List<double>();
        List<double> Y5 = new List<double>();
        List<double> Y6 = new List<double>();
        List<double> Y7 = new List<double>();
        List<double> Y8 = new List<double>();
        List<double> Y9 = new List<double>();

        List<double> X10 = new List<double>();
        List<double> X11 = new List<double>();
        List<double> X12 = new List<double>();
        List<double> X13 = new List<double>();
        List<double> X14 = new List<double>();
        List<double> X15 = new List<double>();
        List<double> X16 = new List<double>();
        List<double> X17 = new List<double>();
        List<double> Y10 = new List<double>();
        List<double> Y11 = new List<double>();
        List<double> Y12 = new List<double>();
        List<double> Y13 = new List<double>();
        List<double> Y14 = new List<double>();
        List<double> Y15 = new List<double>();
        List<double> Y16 = new List<double>();
        List<double> Y17 = new List<double>();


        static int x1;
        static int y1;
        static int x2;
        static int y2;

        double errx1, errx2, errx3, errx4, errx5, errx6, errx7, errx8, errx9;
        double errx10, errx11, errx12, errx13, errx14, errx15, errx16, errx17;
        double erry1, erry2, erry3, erry4, erry5, erry6, erry7, erry8, erry9;
        double erry10, erry11, erry12, erry13, erry14, erry15, erry16, erry17;
        #endregion

        #region Gazepoint dan BackgroundWorker
        BackgroundWorker work = new BackgroundWorker();
        Gazepoint GP = new Gazepoint();
        double[] Hasil = new double[4];
        bool record = false;
        bool status = false;
        int ixx = 0;
        #endregion

        #region Parameter Ellipse dan Quadratic Equation

        double[] LR = new double[4]; // Linear Regression

        double[,] ParameterEllipseX = new double[6, 1]; // Ellipse Regression
        double outmappingx, outmappingy;
        #endregion

        HitungOutputGaze Mapping = new HitungOutputGaze();
        Normalisasi norm_ = new Normalisasi();

        #region normalisasi
        double titik_1_x, titik_2_x, titik_3_x;
        double titik_4_x, titik_5_x, titik_6_x;
        double titik_7_x, titik_8_x, titik_9_x;

        double titik_1_y, titik_2_y, titik_3_y;
        double titik_4_y, titik_5_y, titik_6_y;
        double titik_7_y, titik_8_y, titik_9_y;
        #endregion



        public ValidasiSP()
        {
            InitializeComponent();
        }

        private void ValidasiSP_Load(object sender, EventArgs e)
        {
            int w = Screen.PrimaryScreen.Bounds.Width;
            int h = Screen.PrimaryScreen.Bounds.Height;
            this.Location = new Point(0, 0);
            this.Size = new Size(w, h);

            GP.HidupkanGazepoint();
            work.DoWork += backgroundWorker1_DoWork;
            work.RunWorkerAsync();

            g = Graphics.FromImage(bmp);
            pictureBox1.Image = bmp;
            g.Clear(Color.Black);
            g.FillEllipse(Brushes.Red, titikX1 - 15, titikY1 - 15, 30, 30); // Titik Luar 1
            g.FillEllipse(Brushes.Red, titikX2 - 15, titikY1 - 15, 30, 30); // Titik Luar 2
            g.FillEllipse(Brushes.Red, titikX3 - 15, titikY1 - 15, 30, 30); // Titik Luar 3
            g.FillEllipse(Brushes.Red, titikX1 - 15, titikY2 - 15, 30, 30); // Titik Luar 4 
            g.FillEllipse(Brushes.Red, titikX3 - 15, titikY2 - 15, 30, 30); // Titik Luar 5
            g.FillEllipse(Brushes.Red, titikX1 - 15, titikY3 - 15, 30, 30); // Titik Luar 6
            g.FillEllipse(Brushes.Red, titikX2 - 15, titikY3 - 15, 30, 30); // Titik Luar 7
            g.FillEllipse(Brushes.Red, titikX3 - 15, titikY3 - 15, 30, 30); // Titik Luar 8

            g.FillEllipse(Brushes.Red, titikX4 - 15, titikY4 - 15, 30, 30); // Titik Dalam 1
            g.FillEllipse(Brushes.Red, titikX2 - 15, titikY4 - 15, 30, 30); // Titik Dalam 2
            g.FillEllipse(Brushes.Red, titikX5 - 15, titikY4 - 15, 30, 30); // Titik Dalam 3
            g.FillEllipse(Brushes.Red, titikX4 - 15, titikY2 - 15, 30, 30); // Titik Dalam 4
            g.FillEllipse(Brushes.Red, titikX2 - 15, titikY2 - 15, 30, 30); // Titik Dalam 5
            g.FillEllipse(Brushes.Red, titikX5 - 15, titikY2 - 15, 30, 30); // Titik Dalam 6
            g.FillEllipse(Brushes.Red, titikX4 - 15, titikY5 - 15, 30, 30); // Titik Dalam 7
            g.FillEllipse(Brushes.Red, titikX2 - 15, titikY5 - 15, 30, 30); // Titik Dalam 8
            g.FillEllipse(Brushes.Red, titikX5 - 15, titikY5 - 15, 30, 30); // Titik Dalam 9
        }

        private void ValidasiSP_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                this.Close();

                #region tulis output
                using (StreamWriter outputSP = new StreamWriter("C:\\Users\\Lenovo\\Desktop\\EKSPERIMEN KALIBRASI\\SP.txt", true))
                {
                    outputSP.WriteLine("");

                    outputSP.WriteLine(" ==================== SMOOTH PURSUIT ======================= ");
                    outputSP.WriteLine(" ===== Data Gaze ====== ");
                    outputSP.WriteLine(" Target X : " + titikX1);
                    for (int i = 0; i < X1.Count; i++)
                    {
                        outputSP.WriteLine("Gaze X : " + X1[i] * lebar);
                    }
                    outputSP.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                    outputSP.WriteLine(" Target Y: " + titikY1);
                    for (int i = 0; i < Y1.Count; i++)
                    {
                        outputSP.WriteLine("Gaze Y : " + Y1[i] * tinggi);
                    }
                    outputSP.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                    outputSP.WriteLine("error x 1 : " + errx1);
                    outputSP.WriteLine("error y 1 : " + erry1);

                    outputSP.WriteLine(" ===== Data Gaze ====== ");
                    outputSP.WriteLine(" Target X : " + titikX2);
                    for (int i = 0; i < X2.Count; i++)
                    {
                        outputSP.WriteLine("Gaze X : " + X2[i] * lebar);
                    }
                    outputSP.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                    outputSP.WriteLine(" Target Y: " + titikY1);
                    for (int i = 0; i < Y2.Count; i++)
                    {
                        outputSP.WriteLine("Gaze Y : " + Y2[i] * tinggi);
                    }
                    outputSP.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                    outputSP.WriteLine("error x 2 : " + errx2);
                    outputSP.WriteLine("error y 2 : " + erry2);

                    outputSP.WriteLine(" ===== Data Gaze ====== ");
                    outputSP.WriteLine(" Target X : " + titikX3);
                    for (int i = 0; i < X3.Count; i++)
                    {
                        outputSP.WriteLine("Gaze X : " + X3[i] * lebar);
                    }
                    outputSP.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                    outputSP.WriteLine(" Target Y: " + titikY1);
                    for (int i = 0; i < Y3.Count; i++)
                    {
                        outputSP.WriteLine("Gaze Y : " + Y3[i] * tinggi);
                    }
                    outputSP.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                    outputSP.WriteLine("error x 3 : " + errx3);
                    outputSP.WriteLine("error y 3 : " + erry3);
                    // =====================================================================
                    outputSP.WriteLine(" ===== Data Gaze ====== ");
                    outputSP.WriteLine(" Target X : " + titikX1);
                    for (int i = 0; i < X4.Count; i++)
                    {
                        outputSP.WriteLine("Gaze X : " + X4[i] * lebar);
                    }
                    outputSP.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                    outputSP.WriteLine(" Target Y: " + titikY2);
                    for (int i = 0; i < Y4.Count; i++)
                    {
                        outputSP.WriteLine("Gaze Y : " + Y4[i] * tinggi);
                    }
                    outputSP.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                    outputSP.WriteLine("error x 4 : " + errx4);
                    outputSP.WriteLine("error y 4 : " + erry4);
                    // =======================================================================
                    outputSP.WriteLine(" ===== Data Gaze ====== ");
                    outputSP.WriteLine(" Target X : " + titikX3);
                    for (int i = 0; i < X6.Count; i++)
                    {
                        outputSP.WriteLine("Gaze X : " + X6[i] * lebar);
                    }
                    outputSP.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                    outputSP.WriteLine(" Target Y: " + titikY2);
                    for (int i = 0; i < Y6.Count; i++)
                    {
                        outputSP.WriteLine("Gaze Y : " + Y6[i] * tinggi);
                    }
                    outputSP.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                    outputSP.WriteLine("error x 6 : " + errx6);
                    outputSP.WriteLine("error y 6 : " + erry6);
                    // ========================================================================
                    outputSP.WriteLine(" ===== Data Gaze ====== ");
                    outputSP.WriteLine(" Target X : " + titikX1);
                    for (int i = 0; i < X7.Count; i++)
                    {
                        outputSP.WriteLine("Gaze X : " + X7[i] * lebar);
                    }
                    outputSP.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                    outputSP.WriteLine(" Target Y: " + titikY3);
                    for (int i = 0; i < Y7.Count; i++)
                    {
                        outputSP.WriteLine("Gaze Y : " + Y7[i] * tinggi);
                    }
                    outputSP.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                    outputSP.WriteLine("error x 7 : " + errx7);
                    outputSP.WriteLine("error y 7 : " + erry7);
                    // ========================================================================
                    outputSP.WriteLine(" ===== Data Gaze ====== ");
                    outputSP.WriteLine(" Target X : " + titikX2);
                    for (int i = 0; i < X8.Count; i++)
                    {
                        outputSP.WriteLine("Gaze X : " + X8[i] * lebar);
                    }
                    outputSP.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                    outputSP.WriteLine(" Target Y: " + titikY3);
                    for (int i = 0; i < Y8.Count; i++)
                    {
                        outputSP.WriteLine("Gaze Y : " + Y8[i] * tinggi);
                    }
                    outputSP.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                    outputSP.WriteLine("error x 8 : " + errx8);
                    outputSP.WriteLine("error y 8 : " + erry8);
                    // ========================================================================
                    outputSP.WriteLine(" ===== Data Gaze ====== ");
                    outputSP.WriteLine(" Target X : " + titikX3);
                    for (int i = 0; i < X9.Count; i++)
                    {
                        outputSP.WriteLine("Gaze X : " + X9[i] * lebar);
                    }
                    outputSP.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                    outputSP.WriteLine(" Target Y: " + titikY3);
                    for (int i = 0; i < Y9.Count; i++)
                    {
                        outputSP.WriteLine("Gaze Y : " + Y9[i] * tinggi);
                    }
                    outputSP.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                    outputSP.WriteLine("error x 9 : " + errx9);
                    outputSP.WriteLine("error y 9 : " + erry9);
                    // ========================================================================
                    outputSP.WriteLine(" ===== Data Gaze ====== ");
                    outputSP.WriteLine(" Target X : " + titikX4);
                    for (int i = 0; i < X10.Count; i++)
                    {
                        outputSP.WriteLine("Gaze X : " + X10[i] * lebar);
                    }
                    outputSP.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                    outputSP.WriteLine(" Target Y: " + titikY4);
                    for (int i = 0; i < Y10.Count; i++)
                    {
                        outputSP.WriteLine("Gaze Y : " + Y10[i] * tinggi);
                    }
                    outputSP.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                    outputSP.WriteLine("error x 10 : " + errx10);
                    outputSP.WriteLine("error y 10 : " + erry10);
                    // ========================================================================
                    outputSP.WriteLine(" ===== Data Gaze ====== ");
                    outputSP.WriteLine(" Target X : " + titikX2);
                    for (int i = 0; i < X11.Count; i++)
                    {
                        outputSP.WriteLine("Gaze X : " + X11[i] * lebar);
                    }
                    outputSP.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                    outputSP.WriteLine(" Target Y: " + titikY4);
                    for (int i = 0; i < Y11.Count; i++)
                    {
                        outputSP.WriteLine("Gaze Y : " + Y11[i] * tinggi);
                    }
                    outputSP.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                    outputSP.WriteLine("error x 11 : " + errx11);
                    outputSP.WriteLine("error y 11 : " + erry11);
                    // ========================================================================
                    outputSP.WriteLine(" ===== Data Gaze ====== ");
                    outputSP.WriteLine(" Target X : " + titikX5);
                    for (int i = 0; i < X12.Count; i++)
                    {
                        outputSP.WriteLine("Gaze X : " + X12[i] * lebar);
                    }
                    outputSP.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                    outputSP.WriteLine(" Target Y: " + titikY4);
                    for (int i = 0; i < Y12.Count; i++)
                    {
                        outputSP.WriteLine("Gaze Y : " + Y12[i] * tinggi);
                    }
                    outputSP.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                    outputSP.WriteLine("error x 12 : " + errx12);
                    outputSP.WriteLine("error y 12 : " + erry12);
                    // ========================================================================
                    outputSP.WriteLine(" ===== Data Gaze ====== ");
                    outputSP.WriteLine(" Target X : " + titikX4);
                    for (int i = 0; i < X13.Count; i++)
                    {
                        outputSP.WriteLine("Gaze X : " + X13[i] * lebar);
                    }
                    outputSP.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                    outputSP.WriteLine(" Target Y: " + titikY2);
                    for (int i = 0; i < Y13.Count; i++)
                    {
                        outputSP.WriteLine("Gaze Y : " + Y13[i] * tinggi);
                    }
                    outputSP.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                    outputSP.WriteLine("error x 13 : " + errx13);
                    outputSP.WriteLine("error y 13 : " + erry13);
                    //========================================================================
                    outputSP.WriteLine(" ===== Data Gaze ====== ");
                    outputSP.WriteLine(" Target X : " + titikX2);
                    for (int i = 0; i < X5.Count; i++)
                    {
                        outputSP.WriteLine("Gaze X : " + X5[i] * lebar);
                    }
                    outputSP.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                    outputSP.WriteLine(" Target Y: " + titikY2);
                    for (int i = 0; i < Y5.Count; i++)
                    {
                        outputSP.WriteLine("Gaze Y : " + Y5[i] * tinggi);
                    }
                    outputSP.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                    outputSP.WriteLine("error x 5 : " + errx5);
                    outputSP.WriteLine("error y 5 : " + erry5);
                    // ========================================================================
                    outputSP.WriteLine(" ===== Data Gaze ====== ");
                    outputSP.WriteLine(" Target X : " + titikX5);
                    for (int i = 0; i < X14.Count; i++)
                    {
                        outputSP.WriteLine("Gaze X : " + X14[i] * lebar);
                    }
                    outputSP.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                    outputSP.WriteLine(" Target Y: " + titikY2);
                    for (int i = 0; i < Y14.Count; i++)
                    {
                        outputSP.WriteLine("Gaze Y : " + Y14[i] * tinggi);
                    }
                    outputSP.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                    outputSP.WriteLine("error x 14 : " + errx14);
                    outputSP.WriteLine("error y 14 : " + erry14);
                    // ========================================================================
                    outputSP.WriteLine(" ===== Data Gaze ====== ");
                    outputSP.WriteLine(" Target X : " + titikX4);
                    for (int i = 0; i < X15.Count; i++)
                    {
                        outputSP.WriteLine("Gaze X : " + X15[i] * lebar);
                    }
                    outputSP.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                    outputSP.WriteLine(" Target Y: " + titikY5);
                    for (int i = 0; i < Y15.Count; i++)
                    {
                        outputSP.WriteLine("Gaze Y : " + Y15[i] * tinggi);
                    }
                    outputSP.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                    outputSP.WriteLine("error x 15 : " + errx15);
                    outputSP.WriteLine("error y 15 : " + erry15);
                    // ========================================================================
                    outputSP.WriteLine(" ===== Data Gaze ====== ");
                    outputSP.WriteLine(" Target X : " + titikX2);
                    for (int i = 0; i < X16.Count; i++)
                    {
                        outputSP.WriteLine("Gaze X : " + X16[i] * lebar);
                    }
                    outputSP.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                    outputSP.WriteLine(" Target Y: " + titikY5);
                    for (int i = 0; i < Y16.Count; i++)
                    {
                        outputSP.WriteLine("Gaze Y : " + Y16[i] * tinggi);
                    }
                    outputSP.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                    outputSP.WriteLine("error x 16 : " + errx16);
                    outputSP.WriteLine("error y 16 : " + erry16);
                    // ========================================================================
                    outputSP.WriteLine(" ===== Data Gaze ====== ");
                    outputSP.WriteLine(" Target X : " + titikX5);
                    for (int i = 0; i < X17.Count; i++)
                    {
                        outputSP.WriteLine("Gaze X : " + X17[i] * lebar);
                    }
                    outputSP.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                    outputSP.WriteLine(" Target Y: " + titikY5);
                    for (int i = 0; i < Y17.Count; i++)
                    {
                        outputSP.WriteLine("Gaze Y : " + Y17[i] * tinggi);
                    }
                    outputSP.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                    outputSP.WriteLine("error x 17 : " + errx17);
                    outputSP.WriteLine("error y 17 : " + erry17);
                }
                #endregion
                #region Clear List
                X1.Clear(); X2.Clear(); X3.Clear(); X4.Clear(); X5.Clear(); X6.Clear();
                X7.Clear(); X8.Clear(); X9.Clear(); X10.Clear(); X11.Clear(); X12.Clear();
                X13.Clear(); X14.Clear(); X15.Clear(); X16.Clear(); X17.Clear();

                Y1.Clear(); Y2.Clear(); Y3.Clear(); Y4.Clear(); Y5.Clear(); Y6.Clear();
                Y7.Clear(); Y8.Clear(); Y9.Clear(); Y10.Clear(); Y11.Clear(); Y12.Clear();
                Y13.Clear(); Y14.Clear(); Y15.Clear(); Y16.Clear(); Y17.Clear();
                #endregion

                Debug.WriteLine(" X2 Count : " + X2.Count);
                Debug.WriteLine(" Y2 Count : " + Y2.Count);
                status = true;
            }
            else if (e.KeyCode == Keys.D1)
            {
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                //g.Clear(Color.Black);
                g.FillEllipse(Brushes.Green, titikX1 - 15, titikY1 - 15, 30, 30);
                timer1.Start();
                record = false;
            }
            else if (e.KeyCode == Keys.D2)
            {
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                //g.Clear(Color.Black);
                g.FillEllipse(Brushes.Green, titikX2 - 15, titikY1 - 15, 30, 30);
                timer2.Start();
                record = false;
            }
            else if (e.KeyCode == Keys.D3)
            {
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Green, titikX3 - 15, titikY1 - 15, 30, 30);
                timer3.Start();
                record = false;
            }
            else if (e.KeyCode == Keys.D4)
            {
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Green, titikX1 - 15, titikY2 - 15, 30, 30);
                timer4.Start();
                record = false;
            }
            else if (e.KeyCode == Keys.T)
            {
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Green, titikX2 - 15, titikY2 - 15, 30, 30);
                timer5.Start();
                record = false;
            }
            else if (e.KeyCode == Keys.D5)
            {
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Green, titikX3 - 15, titikY2 - 15, 30, 30);
                timer6.Start();
                record = false;
            }
            else if (e.KeyCode == Keys.D6)
            {
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Green, titikX1 - 15, titikY3 - 15, 30, 30);
                timer7.Start();
                record = false;
            }
            else if (e.KeyCode == Keys.D7)
            {
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Green, titikX2 - 15, titikY3 - 15, 30, 30);
                timer8.Start();
                record = false;
            }
            else if (e.KeyCode == Keys.D8)
            {
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Green, titikX3 - 15, titikY3 - 15, 30, 30);
                timer9.Start();
                record = false;
            }
            else if (e.KeyCode == Keys.Q)
            {
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Green, titikX4 - 15, titikY4 - 15, 30, 30);
                timer10.Start();
                record = false;
            }
            else if (e.KeyCode == Keys.W)
            {
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Green, titikX2 - 15, titikY4 - 15, 30, 30);
                timer11.Start();
                record = false;
            }
            else if (e.KeyCode == Keys.E)
            {
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Green, titikX5 - 15, titikY4 - 15, 30, 30);
                timer12.Start();
                record = false;
            }
            else if (e.KeyCode == Keys.R)
            {
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Green, titikX4 - 15, titikY2 - 15, 30, 30);
                timer13.Start();
                record = false;
            }
            else if (e.KeyCode == Keys.Y)
            {
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Green, titikX5 - 15, titikY2 - 15, 30, 30);
                timer14.Start();
                record = false;
            }
            else if (e.KeyCode == Keys.U)
            {
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Green, titikX4 - 15, titikY5 - 15, 30, 30);
                timer15.Start();
                record = false;
            }
            else if (e.KeyCode == Keys.I)
            {
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Green, titikX2 - 15, titikY5 - 15, 30, 30);
                timer16.Start();
                record = false;
            }
            else if (e.KeyCode == Keys.O)
            {
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Green, titikX5 - 15, titikY5 - 15, 30, 30);
                timer17.Start();
                record = false;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timesec++;
            titik_1_x = norm_.NormalisasiX(titikX1);
            titik_1_y = norm_.NormalisasiY(titikY1);
            if (Hasil[2] != 0)
            {
                outmappingx = LR[0] + LR[1] * Hasil[0]; // Linear Regression
                outmappingy = LR[2] + LR[3] * Hasil[1]; // Linear Regression

                X1.Add(outmappingx);
                Y1.Add(outmappingy);
            }

            if (X1.Count > 4)
            {
                timer1.Stop();
                record = true;
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Red, titikX1 - 15, titikY1 - 15, 30, 30);
                Debug.WriteLine(" ==================== SMOOTH PURSUIT ======================= ");
                Debug.WriteLine(" ===== Data Gaze ====== ");
                errx1 = HitungError(X1, titikX1, lebar);
                Debug.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                erry1 = HitungError(Y1, titikY1, tinggi);
                Debug.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                label1.Text = "Error X : " + Math.Round(errx1, 2) + " , " + "\r\n" + "Error Y : " + Math.Round(erry1, 2);
                Debug.WriteLine("error x 1 : " + errx1);
                Debug.WriteLine("error y 1 : " + erry1);
                outmappingx = 0;
                outmappingy = 0;
                timesec = 0;
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            timesec2++;
            titik_2_x = norm_.NormalisasiX(titikX2);
            titik_2_y = norm_.NormalisasiY(titikY1);
            if (Hasil[2] != 0)
            {
                outmappingx = LR[0] + LR[1] * Hasil[0]; // Linear Regression
                outmappingy = LR[2] + LR[3] * Hasil[1]; // Linear Regression
                //outmapping = Mapping.EllipseRegression(ParameterEllipseX, Hasil[0], titik_1_x); //&&&&&&&&&&&&&&&&&
                X2.Add(outmappingx);
                Y2.Add(outmappingy);
            }

            if (X2.Count > 4)
            {
                timer2.Stop();
                //status = true;
                record = true;
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Red, titikX2 - 15, titikY1 - 15, 30, 30);
                Debug.WriteLine(" ===== Data Gaze ====== ");
                errx2 = HitungError(X2, titikX2, lebar);
                Debug.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                erry2 = HitungError(Y2, titikY1, tinggi);
                Debug.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                label2.Text = "Error X : " + Math.Round(errx2, 2) + " , " + "\r\n" + "Error Y : " + Math.Round(erry2, 2);
                Debug.WriteLine("error x 2 : " + errx2);
                Debug.WriteLine("error y 2 : " + erry2);
                outmappingx = 0;
                outmappingy = 0;
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            timesec3++;
            titik_3_x = norm_.NormalisasiX(titikX3);
            titik_3_y = norm_.NormalisasiY(titikY1);

            if (Hasil[2] != 0)
            {
                outmappingx = LR[0] + LR[1] * Hasil[0]; // Linear Regression
                outmappingy = LR[2] + LR[3] * Hasil[1]; // Linear Regression
                //outmapping = Mapping.EllipseRegression(ParameterEllipseX, Hasil[0], titik_1_x); //&&&&&&&&&&&&&&&&&
                X3.Add(outmappingx);
                Y3.Add(outmappingy);
            }

            if (X3.Count > 4)
            {
                //status = true;
                record = true;
                timer3.Stop();
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Red, titikX3 - 15, titikY1 - 15, 30, 30);
                Debug.WriteLine(" ===== Data Gaze ====== ");
                errx3 = HitungError(X3, titikX3, lebar);
                Debug.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                erry3 = HitungError(Y3, titikY1, tinggi);
                Debug.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                label3.Text = "Error X : " + Math.Round(errx3, 2) + " , " + "\r\n" + "Error Y : " + Math.Round(erry3, 2);
                Debug.WriteLine("error x 3 : " + errx3);
                Debug.WriteLine("error y 3 : " + erry3);
                outmappingx = 0;
                outmappingy = 0;
            }
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            while (status == false)
            {
                Hasil = GP.DapatDataGaze();

                //Debug.WriteLine("Data X  : " + (int)(Hasil[0] * 1366));
            }
            GP.MatikanGazepoint();

        }

        private void timer4_Tick(object sender, EventArgs e)
        {
            timesec4++;
            titik_4_x = norm_.NormalisasiX(titikX1);
            titik_4_y = norm_.NormalisasiY(titikY2);

            if (Hasil[2] != 0)
            {
                outmappingx = LR[0] + LR[1] * Hasil[0]; // Linear Regression
                outmappingy = LR[2] + LR[3] * Hasil[1]; // Linear Regression
                //outmapping = Mapping.EllipseRegression(ParameterEllipseX, Hasil[0], titik_1_x); //&&&&&&&&&&&&&&&&&
                X4.Add(outmappingx);
                Y4.Add(outmappingy);
            }

            if (X4.Count > 4)
            {
                timer4.Stop();
                record = true;
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Red, titikX1 - 15, titikY2 - 15, 30, 30);
                Debug.WriteLine(" ===== Data Gaze ====== ");
                errx4 = HitungError(X4, titikX1, lebar);
                Debug.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                erry4 = HitungError(Y4, titikY2, tinggi);
                Debug.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                label4.Text = "Error X : " + Math.Round(errx4, 2) + " , " + "\r\n" + "Error Y : " + Math.Round(erry4, 2);
                Debug.WriteLine("error x 4 : " + errx4);
                Debug.WriteLine("error y 4 : " + erry4);
                outmappingx = 0;
                outmappingy = 0;
            }
        }

        private void timer6_Tick(object sender, EventArgs e)
        {
            timesec6++;
            titik_6_x = norm_.NormalisasiX(titikX3);
            titik_6_y = norm_.NormalisasiY(titikY2);

            if (Hasil[2] != 0)
            {
                outmappingx = LR[0] + LR[1] * Hasil[0]; // Linear Regression
                outmappingy = LR[2] + LR[3] * Hasil[1]; // Linear Regression
                //outmapping = Mapping.EllipseRegression(ParameterEllipseX, Hasil[0], titik_1_x); //&&&&&&&&&&&&&&&&&
                X6.Add(outmappingx);
                Y6.Add(outmappingy);
            }

            if (X6.Count > 4)
            {
                timer6.Stop();
                record = true;
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Red, titikX3 - 15, titikY2 - 15, 30, 30);
                Debug.WriteLine(" ===== Data Gaze ====== ");
                errx6 = HitungError(X6, titikX3, lebar);
                Debug.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                erry6 = HitungError(Y6, titikY2, tinggi);
                Debug.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                label6.Text = "Error X : " + Math.Round(errx6, 2) + " , " + "\r\n" + "Error Y : " + Math.Round(erry6, 2);
                Debug.WriteLine("error x 6 : " + errx6);
                Debug.WriteLine("error y 6 : " + erry6);
                outmappingx = 0; outmappingy = 0;

            }
        }

        private void timer7_Tick(object sender, EventArgs e)
        {
            timesec7++;
            titik_7_x = norm_.NormalisasiX(titikX1);
            titik_7_y = norm_.NormalisasiY(titikY3);

            if (Hasil[2] != 0)
            {
                outmappingx = LR[0] + LR[1] * Hasil[0]; // Linear Regression
                outmappingy = LR[2] + LR[3] * Hasil[1]; // Linear Regression
                //outmapping = Mapping.EllipseRegression(ParameterEllipseX, Hasil[0], titik_1_x); //&&&&&&&&&&&&&&&&&
                X7.Add(outmappingx);
                Y7.Add(outmappingy);
            }

            if (X7.Count > 4)
            {
                timer7.Stop();
                record = true;
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Red, titikX1 - 15, titikY3 - 15, 30, 30);
                errx7 = HitungError(X7, titikX1, lebar);
                erry7 = HitungError(Y7, titikY3, tinggi);
                label7.Text = "Error X : " + Math.Round(errx7, 2) + " , " + "\r\n" + "Error Y : " + Math.Round(erry7, 2);
                Debug.WriteLine("error x 7 : " + errx7);
                Debug.WriteLine("error y 7 : " + erry7);
                outmappingx = 0; outmappingy = 0;

            }
        }

        private void timer8_Tick(object sender, EventArgs e)
        {
            timesec8++;
            titik_8_x = norm_.NormalisasiX(titikX2);
            titik_8_y = norm_.NormalisasiY(titikY3);

            if (Hasil[2] != 0)
            {
                outmappingx = LR[0] + LR[1] * Hasil[0]; // Linear Regression
                outmappingy = LR[2] + LR[3] * Hasil[1]; // Linear Regression
                //outmapping = Mapping.EllipseRegression(ParameterEllipseX, Hasil[0], titik_1_x); //&&&&&&&&&&&&&&&&&
                X8.Add(outmappingx);
                Y8.Add(outmappingy);
            }

            if (X8.Count > 4)
            {
                timer8.Stop();
                record = true;
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Red, titikX2 - 15, titikY3 - 15, 30, 30);
                Debug.WriteLine(" ===== Data Gaze ====== ");
                errx8 = HitungError(X8, titikX2, lebar);
                Debug.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                erry8 = HitungError(Y8, titikY3, tinggi);
                Debug.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                label8.Text = "Error X : " + Math.Round(errx8, 2) + " , " + "\r\n" + "Error Y : " + Math.Round(erry8, 2);
                Debug.WriteLine("error x 8 : " + errx8);
                Debug.WriteLine("error y 8 : " + erry8);
                outmappingx = 0; outmappingy = 0;

            }
        }

        private void timer9_Tick(object sender, EventArgs e)
        {
            timesec9++;
            titik_9_x = norm_.NormalisasiX(titikX3);
            titik_9_y = norm_.NormalisasiY(titikY3);

            if (Hasil[2] != 0)
            {
                outmappingx = LR[0] + LR[1] * Hasil[0]; // Linear Regression
                outmappingy = LR[2] + LR[3] * Hasil[1]; // Linear Regression
                //outmapping = Mapping.EllipseRegression(ParameterEllipseX, Hasil[0], titik_1_x); //&&&&&&&&&&&&&&&&&
                X9.Add(outmappingx);
                Y9.Add(outmappingy);
            }

            if (X9.Count > 4)
            {
                timer9.Stop();
                record = true;
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Red, titikX3 - 15, titikY3 - 15, 30, 30);
                Debug.WriteLine(" ===== Data Gaze ====== ");
                errx9 = HitungError(X9, titikX3, lebar);
                Debug.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                erry9 = HitungError(Y9, titikY3, tinggi);
                Debug.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                label9.Text = "Error X : " + Math.Round(errx9, 2) + " , " + "\r\n" + "Error Y : " + Math.Round(erry9, 2);
                Debug.WriteLine("error x 9 : " + errx9);
                Debug.WriteLine("error y 9 : " + erry9);
                outmappingx = 0; outmappingy = 0;

            }
        }


        public double[,] ParamEllipseX(double[,] parameter)
        {
            for (int i = 0; i < 6; i++)
            {
                ParameterEllipseX[i, 0] = parameter[i, 0];
            }

            return ParameterEllipseX;
        }

        public double[] LinearReg(double a, double b, double c, double d)
        {

            LR[0] = a;
            LR[1] = b;
            LR[2] = c;
            LR[3] = d;

            return LR;
        }

        private double HitungError(List<double> gaze, double target, int size)
        {
            double rata2;
            double hasilerror = 0.00;
            double[] _gaze = gaze.ToArray();

            Debug.WriteLine("titik target : " + target);

            for (int i = 0; i < _gaze.Length; i++)
            {
                hasilerror += Math.Sqrt(Math.Pow((_gaze[i] * size) - target, 2));

                Debug.WriteLine("gaze : " + _gaze[i] * size);
                //Debug.WriteLine("hasil error : " + hasilerror);
            }

            rata2 = hasilerror / _gaze.Length;

            return rata2;
        }

        private void timer10_Tick(object sender, EventArgs e) // titik dalam 1
        {
            timesec10++;
            //titik_10_x = norm_.NormalisasiX(titikX3);
            //titik_10_y = norm_.NormalisasiY(titikY3);

            if (Hasil[2] != 0)
            {
                outmappingx = LR[0] + LR[1] * Hasil[0]; // Linear Regression
                outmappingy = LR[2] + LR[3] * Hasil[1]; // Linear Regression
                //outmapping = Mapping.EllipseRegression(ParameterEllipseX, Hasil[0], titik_1_x); //&&&&&&&&&&&&&&&&&
                X10.Add(outmappingx);
                Y10.Add(outmappingy);
            }

            if (X10.Count > 4)
            {
                timer10.Stop();
                record = true;
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Red, titikX4 - 15, titikY4 - 15, 30, 30); // Titik Dalam 1
                Debug.WriteLine(" ===== Data Gaze ====== ");
                errx10 = HitungError(X10, titikX4, lebar);
                Debug.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                erry10 = HitungError(Y10, titikY4, tinggi);
                Debug.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                label10.Text = "Error X : " + Math.Round(errx10, 2) + " , " + "\r\n" + "Error Y : " + Math.Round(erry10, 2);
                Debug.WriteLine("error x 10 : " + errx10);
                Debug.WriteLine("error y 10 : " + erry10);
                outmappingx = 0; outmappingy = 0;

            }
        }

        private void timer11_Tick(object sender, EventArgs e) // titik dalam 2
        {
            timesec11++;
            //titik_11_x = norm_.NormalisasiX(titikX3);
            //titik_11_y = norm_.NormalisasiY(titikY3);

            if (Hasil[2] != 0)
            {
                outmappingx = LR[0] + LR[1] * Hasil[0]; // Linear Regression
                outmappingy = LR[2] + LR[3] * Hasil[1]; // Linear Regression
                //outmapping = Mapping.EllipseRegression(ParameterEllipseX, Hasil[0], titik_1_x); //&&&&&&&&&&&&&&&&&
                X11.Add(outmappingx);
                Y11.Add(outmappingy);
            }

            if (X11.Count > 4)
            {
                timer11.Stop();
                record = true;
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Red, titikX2 - 15, titikY4 - 15, 30, 30); // Titik Dalam 2
                Debug.WriteLine(" ===== Data Gaze ====== ");
                errx11 = HitungError(X11, titikX2, lebar);
                Debug.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                erry11 = HitungError(Y11, titikY4, tinggi);
                Debug.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                label11.Text = "Error X : " + Math.Round(errx11, 2) + " , " + "\r\n" + "Error Y : " + Math.Round(erry11, 2);
                Debug.WriteLine("error x 11 : " + errx11);
                Debug.WriteLine("error y 11 : " + erry11);
                outmappingx = 0; outmappingy = 0;

            }
        }

        private void timer12_Tick(object sender, EventArgs e) // titik dalam 3
        {
            timesec12++;
            //titik_12_x = norm_.NormalisasiX(titikX3);
            //titik_12_y = norm_.NormalisasiY(titikY3); 

            if (Hasil[2] != 0)
            {
                outmappingx = LR[0] + LR[1] * Hasil[0]; // Linear Regression
                outmappingy = LR[2] + LR[3] * Hasil[1]; // Linear Regression
                //outmapping = Mapping.EllipseRegression(ParameterEllipseX, Hasil[0], titik_1_x); //&&&&&&&&&&&&&&&&&
                X12.Add(outmappingx);
                Y12.Add(outmappingy);
            }

            if (X12.Count > 4)
            {
                timer12.Stop();
                record = true;
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Red, titikX5 - 15, titikY4 - 15, 30, 30); // Titik Dalam 3
                Debug.WriteLine(" ===== Data Gaze ====== ");
                errx12 = HitungError(X12, titikX5, lebar);
                Debug.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                erry12 = HitungError(Y12, titikY4, tinggi);
                Debug.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                label12.Text = "Error X : " + Math.Round(errx12, 2) + " , " + "\r\n" + "Error Y : " + Math.Round(erry12, 2);
                Debug.WriteLine("error 12 : " + errx12);
                Debug.WriteLine("error y 12 : " + erry12);
                outmappingx = 0; outmappingy = 0;

            }
        }

        private void timer13_Tick(object sender, EventArgs e) // titik dalam 4
        {
            timesec13++;
            //titik_13_x = norm_.NormalisasiX(titikX3);
            //titik_13_y = norm_.NormalisasiY(titikY3); 

            if (Hasil[2] != 0)
            {
                outmappingx = LR[0] + LR[1] * Hasil[0]; // Linear Regression
                outmappingy = LR[2] + LR[3] * Hasil[1]; // Linear Regression
                //outmapping = Mapping.EllipseRegression(ParameterEllipseX, Hasil[0], titik_1_x); //&&&&&&&&&&&&&&&&&
                X13.Add(outmappingx);
                Y13.Add(outmappingy);
            }

            if (X13.Count > 4)
            {
                timer13.Stop();
                record = true;
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Red, titikX4 - 15, titikY2 - 15, 30, 30); // Titik Dalam 4
                Debug.WriteLine(" ===== Data Gaze ====== ");
                errx13 = HitungError(X13, titikX4, lebar);
                Debug.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                erry13 = HitungError(Y13, titikY2, tinggi);
                Debug.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                label13.Text = "Error X : " + Math.Round(errx13, 2) + " , " + "\r\n" + "Error Y : " + Math.Round(erry13, 2);
                Debug.WriteLine("error 13 : " + errx13);
                Debug.WriteLine("error y 13 : " + erry13);
                outmappingx = 0; outmappingy = 0;

            }
        }

        private void timer5_Tick(object sender, EventArgs e) // titik dalam 5
        {
            timesec5++;
            titik_5_x = norm_.NormalisasiX(titikX2);
            titik_5_y = norm_.NormalisasiY(titikY2);

            if (Hasil[2] != 0)
            {
                outmappingx = LR[0] + LR[1] * Hasil[0]; // Linear Regression
                outmappingy = LR[2] + LR[3] * Hasil[1]; // Linear Regression
                //outmapping = Mapping.EllipseRegression(ParameterEllipseX, Hasil[0], titik_1_x); //&&&&&&&&&&&&&&&&&
                X5.Add(outmappingx);
                Y5.Add(outmappingy);
            }

            if (X5.Count > 4)
            {
                timer5.Stop();
                record = true;
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Red, titikX2 - 15, titikY2 - 15, 30, 30);
                Debug.WriteLine(" ===== Data Gaze ====== ");
                errx5 = HitungError(X5, titikX2, lebar);
                Debug.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                erry5 = HitungError(Y5, titikY2, tinggi);
                Debug.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                label5.Text = "Error X : " + Math.Round(errx5, 2) + " , " + "\r\n" + "Error Y : " + Math.Round(erry5, 2);
                Debug.WriteLine("error 5 : " + errx5);
                Debug.WriteLine("error y 5 : " + erry5);
                outmappingx = 0; outmappingy = 0;

            }
        }

        private void timer14_Tick(object sender, EventArgs e) // titik dalam 6
        {
            timesec14++;
            //titik_14_x = norm_.NormalisasiX(titikX3);
            //titik_14_y = norm_.NormalisasiY(titikY3); 

            if (Hasil[2] != 0)
            {
                outmappingx = LR[0] + LR[1] * Hasil[0]; // Linear Regression
                outmappingy = LR[2] + LR[3] * Hasil[1]; // Linear Regression
                //outmapping = Mapping.EllipseRegression(ParameterEllipseX, Hasil[0], titik_1_x); //&&&&&&&&&&&&&&&&&
                X14.Add(outmappingx);
                Y14.Add(outmappingy);
            }

            if (X14.Count > 4)
            {
                timer14.Stop();
                record = true;
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Red, titikX5 - 15, titikY2 - 15, 30, 30); // Titik Dalam 6
                Debug.WriteLine(" ===== Data Gaze ====== ");
                errx14 = HitungError(X14, titikX5, lebar);
                Debug.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                erry14 = HitungError(Y14, titikY2, tinggi);
                Debug.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                label14.Text = "Error X : " + Math.Round(errx14, 2) + " , " + "\r\n" + "Error Y : " + Math.Round(erry14, 2);
                Debug.WriteLine("error 14 : " + errx14);
                Debug.WriteLine("error y 14 : " + erry14);
                outmappingx = 0; outmappingy = 0;

            }
        }

        private void timer15_Tick(object sender, EventArgs e) // titik dalam 7
        {
            timesec15++;
            //titik_15_x = norm_.NormalisasiX(titikX3);
            //titik_15_y = norm_.NormalisasiY(titikY3); 

            if (Hasil[2] != 0)
            {
                outmappingx = LR[0] + LR[1] * Hasil[0]; // Linear Regression
                outmappingy = LR[2] + LR[3] * Hasil[1]; // Linear Regression
                //outmapping = Mapping.EllipseRegression(ParameterEllipseX, Hasil[0], titik_1_x); //&&&&&&&&&&&&&&&&&
                X15.Add(outmappingx);
                Y15.Add(outmappingy);
                //Debug.WriteLine("Data X 1 : " + (int)(Hasil[0] * 1566));
            }

            if (X15.Count > 4)
            {
                timer15.Stop();
                record = true;
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Red, titikX4 - 15, titikY5 - 15, 30, 30); // Titik Dalam 7
                Debug.WriteLine(" ===== Data Gaze ====== ");
                errx15 = HitungError(X15, titikX4, lebar);
                Debug.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                erry15 = HitungError(Y15, titikY5, tinggi);
                Debug.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                label15.Text = "Error X : " + Math.Round(errx15, 2) + " , " + "\r\n" + "Error Y : " + Math.Round(erry15, 2);
                Debug.WriteLine("error 15 : " + errx15);
                Debug.WriteLine("error y 15 : " + erry15);
                outmappingx = 0; outmappingy = 0;

            }
        }

        private void timer16_Tick(object sender, EventArgs e) // titik dalam 8 
        {
            timesec16++;
            //titik_16_x = norm_.NormalisasiX(titikX3);
            //titik_16_y = norm_.NormalisasiY(titikY3); 

            if (Hasil[2] != 0)
            {
                outmappingx = LR[0] + LR[1] * Hasil[0]; // Linear Regression
                outmappingy = LR[2] + LR[3] * Hasil[1]; // Linear Regression
                //outmapping = Mapping.EllipseRegression(ParameterEllipseX, Hasil[0], titik_1_x); //&&&&&&&&&&&&&&&&&
                X16.Add(outmappingx);
                Y16.Add(outmappingy);
                //Debug.WriteLine("Data X 1 : " + (int)(Hasil[0] * 1666));
            }

            if (X16.Count > 4)
            {
                timer16.Stop();
                record = true;
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Red, titikX2 - 15, titikY5 - 15, 30, 30); // Titik Dalam 8
                Debug.WriteLine(" ===== Data Gaze ====== ");
                errx16 = HitungError(X16, titikX2, lebar);
                Debug.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                erry16 = HitungError(Y16, titikY5, tinggi);
                Debug.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                label16.Text = "Error X : " + Math.Round(errx16, 2) + " , " + "\r\n" + "Error Y : " + Math.Round(erry16, 2);
                Debug.WriteLine("error 16 : " + errx16);
                Debug.WriteLine("error y 16 : " + erry16);
                outmappingx = 0; outmappingy = 0;

            }
        }

        private void timer17_Tick(object sender, EventArgs e) // titik dalam 9
        {
            timesec17++;
            //titik_17_x = norm_.NormalisasiX(titikX3);
            //titik_17_y = norm_.NormalisasiY(titikY3); 

            if (Hasil[2] != 0)
            {
                outmappingx = LR[0] + LR[1] * Hasil[0]; // Linear Regression
                outmappingy = LR[2] + LR[3] * Hasil[1]; // Linear Regression
                //outmapping = Mapping.EllipseRegression(ParameterEllipseX, Hasil[0], titik_1_x); //&&&&&&&&&&&&&&&&&
                X17.Add(outmappingx);
                Y17.Add(outmappingy);
            }

            if (X17.Count > 4)
            {
                timer17.Stop();
                record = true;
                g = Graphics.FromImage(bmp);
                pictureBox1.Image = bmp;
                g.FillEllipse(Brushes.Red, titikX5 - 15, titikY5 - 15, 30, 30); // Titik Dalam 9
                Debug.WriteLine(" ===== Data Gaze ====== ");
                errx17 = HitungError(X17, titikX5, lebar);
                Debug.WriteLine(" ===== xxxxxxxxxxxxxxxxx ===== ");
                erry17 = HitungError(Y17, titikY5, tinggi);
                Debug.WriteLine(" ===== yyyyyyyyyyyyyyyyy ===== ");
                label17.Text = "Error X : " + Math.Round(errx17, 2) + " , " + "\r\n" + "Error Y : " + Math.Round(erry17, 2);
                Debug.WriteLine("error 17 : " + errx17);
                Debug.WriteLine("error y 17 : " + erry17);
                outmappingx = 0; outmappingy = 0;

            }
        }
    }
}
