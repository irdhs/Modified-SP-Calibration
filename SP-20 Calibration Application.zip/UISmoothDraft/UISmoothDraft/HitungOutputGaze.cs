﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UISmoothDraft
{
    class HitungOutputGaze
    {
        public double EllipseRegression(double[,] parameter, double x, double target)
        {
            //parameter A = [0,0], B = [1,0], C = [2,0], D = [3,0], E = [4,0], F = [5,0]
            //Ax^2 + Bxy + Cy^2 + Dx + Ey + F = 0
            //Cy^2 + (Bxy + Ey) + (Ax^2 + Dx + F) = 0
            //a = C ; b = (Bxy + Ey) ; c = (Ax^2 + Dx + F)
            double a, b, c;
            double[] y = new double[2];
            double hasil;

            a = parameter[2, 0];
            b = parameter[1, 0] * x + parameter[4, 0];
            c = parameter[0, 0] * (x * x) + parameter[3, 0] * x + parameter[5, 0];

            y = SolveQuadratic(a, b, c);
            hasil = hasilOutput(y, target);

            return hasil;
        }

        public double hasilOutput(double[] y, double target)
        {
            double y1, y2;
            double output = 0;

            y1 = Math.Sqrt(Math.Pow(y[0] - target, 2));
            y2 = Math.Sqrt(Math.Pow(y[1] - target, 2));

            if (y1 < y2)
            {
                output = y[0];

            } 
            else if (y1 > y2)
            {
                output = y[1];
            }
            else
            {
                output = y[1];
            }
            //output = y.Min();

            return output;
        }

        public double[] SolveQuadratic(double a, double b, double c)
        {
            double[] outputY = new double[2];
            double sqrtpart = (b * b) - (4 * a * c);

            if (sqrtpart > 0)
            {
                outputY[0] = (-b + Math.Sqrt(sqrtpart)) / (2 * a);
                outputY[1] = (-b - Math.Sqrt(sqrtpart)) / (2 * a);
            }
            else if(sqrtpart < 0)
            {
                outputY[0] = (-b + Math.Sqrt(Math.Abs(sqrtpart))) / (2 * a);
                outputY[1] = (-b - Math.Sqrt(Math.Abs(sqrtpart))) / (2 * a);
            }
            else
            {
                outputY[0] = (-b + Math.Sqrt(sqrtpart)) / (2 * a);
                outputY[1] = (-b - Math.Sqrt(sqrtpart)) / (2 * a);
            }

            return outputY;
        }
    }
}
